import React, { useState, useEffect, useRef, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Hammer, Sparkles, Coins, Flame, Shield, Briefcase, Archive,
  Store, TestTube, RotateCcw, Volume2, VolumeX, AlertOctagon, 
  ChevronRight, Compass, Swords, CornerDownRight, Check, Play, Info,
  Plus, Trash2, FolderDown
} from 'lucide-react';
import { 
  GameState, SWORDS_DB, JUNK_NAMES, JunkType, JSTState, SwordInfo 
} from '../types';
import { sound } from '../sound';
import FileModal from './FileModal';

// Initial Game State Default values
const INITIAL_STATE: GameState = {
  difficulty: 'EASY',
  money: 10000,
  currentSwordLevel: 0,
  protectCards: 0,
  storage: {
    wangpu: 0,
    tempest: 0,
    sharp: 0,
  },
  junks: {
    ironPiece: 0,
    tauBone: 0,
    fluorescence: 0,
    swissIron: 0,
    fieryHandle: 0,
    evilSoul: 0,
    axePowder: 0,
    invisibleMaterial: 0,
  },
  droppedJunk: null,
  tempStorage: [],
  currentMap: '대장간',
  protectCardEnabled: true,
  history: ['대장간에 어서 오십시오! 낡은 단검(+0)으로 칼강 인생이 시작됩니다.'],
  statistics: {
    totalAttempts: 0,
    totalSuccesses: 0,
    totalFails: 0,
    totalDestructions: 0,
    totalMoneySpent: 0,
    maxLevelReached: 0,
  },
};

export default function ForgeGame() {
  const [state, setState] = useState<GameState>(() => {
    const saved = localStorage.getItem('forge_game_easy_state');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        
        let normalizedTempStorage: Array<{ level: number; name: string }> = [];
        if (parsed.tempStorage) {
          if (Array.isArray(parsed.tempStorage)) {
            normalizedTempStorage = parsed.tempStorage;
          } else if (parsed.tempStorage.level !== undefined) {
            normalizedTempStorage = [parsed.tempStorage];
          }
        }

        // Ensure standard fields
        return {
          ...INITIAL_STATE,
          ...parsed,
          tempStorage: normalizedTempStorage,
          statistics: { ...INITIAL_STATE.statistics, ...(parsed.statistics || {}) }
        };
      } catch (e) {
        return INITIAL_STATE;
      }
    }
    return INITIAL_STATE;
  });

  const [isForging, setIsForging] = useState(false);
  const [isCombating, setIsCombating] = useState(false);
  const [isConsecutive, setIsConsecutive] = useState(false);
  
  const stateRef = useRef(state);
  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  const [forgeResult, setForgeResult] = useState<'success' | 'fail' | 'destruct' | null>(null);
  const [activeTab, setActiveTab] = useState<'forge' | 'temp_storage' | 'storage' | 'shop' | 'alchemy' | 'combat' | 'stats'>('forge');
  const [consoleInput, setConsoleInput] = useState('');
  const [soundMuted, setSoundMuted] = useState(sound.getMuteState());
  const [shakeScreen, setShakeScreen] = useState(false);
  const [showClearConfetti, setShowClearConfetti] = useState(false);
  const [showFileModal, setShowFileModal] = useState(false);
  
  // Warp tickets tracking inside state. Instead of complex DB, we store warpTickets in state.
  const [warpTickets, setWarpTickets] = useState<{ [key: number]: number }>({
    9: 0,
    13: 0,
    14: 0,
    15: 0,
  });

  const [isAutoCombat, setIsAutoCombat] = useState(false);
  const [autoCombatStageNum, setAutoCombatStageNum] = useState<number | null>(null);

  const isAutoCombatRef = useRef(isAutoCombat);
  useEffect(() => {
    isAutoCombatRef.current = isAutoCombat;
  }, [isAutoCombat]);

  const isCombatingRef = useRef(isCombating);
  useEffect(() => {
    isCombatingRef.current = isCombating;
  }, [isCombating]);

  const isForgingRef = useRef(isForging);
  useEffect(() => {
    isForgingRef.current = isForging;
  }, [isForging]);

  const [successEffectTrigger, setSuccessEffectTrigger] = useState(0);
  const [showSuccessOverlay, setShowSuccessOverlay] = useState(false);

  useEffect(() => {
    if (successEffectTrigger > 0) {
      setShowSuccessOverlay(true);
      const timer = setTimeout(() => {
        setShowSuccessOverlay(false);
      }, 1550);
      return () => clearTimeout(timer);
    }
  }, [successEffectTrigger]);

  const successParticles = useMemo(() => {
    if (successEffectTrigger === 0) return [];
    
    // Create 32 gorgeous explosive particles with different pathways, sizes, and shapes
    return Array.from({ length: 32 }).map((_, idx) => {
      const angle = (idx * 360) / 32 + (Math.random() * 16 - 8);
      const radian = (angle * Math.PI) / 180;
      // Varied burst distance for a organic splash shape
      const distance = 80 + Math.random() * 110;
      const xTarget = Math.cos(radian) * distance;
      // Give it a subtle airy floating lift or natural light gravity drop effect on Y axis
      const yTarget = Math.sin(radian) * distance - (Math.random() * 30);
      const size = 5 + Math.random() * 12;
      const delay = Math.random() * 0.15;
      const duration = 0.7 + Math.random() * 0.6; // Longer lasting sparkles
      
      const colors = [
        // Sparkly deep gold
        'bg-amber-400 shadow-[0_0_12px_rgba(251,191,36,0.9)] border border-yellow-200/50',
        // Radiant neon teal/cyan
        'bg-cyan-400 shadow-[0_0_12px_rgba(34,211,238,0.9)] border border-cyan-200/50',
        // Magical violet/pink
        'bg-fuchsia-400 shadow-[0_0_12px_rgba(232,121,249,0.9)] border border-fuchsia-200/50',
        // Bright emerald flare
        'bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.9)] border border-emerald-200/50',
        // Premium diamond white
        'bg-white shadow-[0_0_15px_rgba(255,255,255,1.0)] border border-neutral-100',
        // Sunset rose gold
        'bg-rose-400 shadow-[0_0_12px_rgba(251,113,133,0.9)] border border-rose-200/50',
      ];
      const color = colors[idx % colors.length];
      
      // Categorize shapes
      let shape: 'circle' | 'star' | 'diamond' | 'ring' = 'circle';
      if (idx % 4 === 0) shape = 'star';
      else if (idx % 4 === 1) shape = 'diamond';
      else if (idx % 4 === 2) shape = 'ring';

      return {
        id: `${successEffectTrigger}-${idx}`,
        xTarget,
        yTarget,
        size,
        delay,
        duration,
        color,
        shape,
        rotateTarget: (Math.random() > 0.5 ? 360 : -360) + (Math.random() * 180 - 90)
      };
    });
  }, [successEffectTrigger]);

  const canSynthesize = useMemo(() => {
    return (
      (state.junks.ironPiece >= 5) ||
      (state.junks.tauBone >= 3) ||
      (state.junks.fluorescence >= 2) ||
      (state.junks.swissIron >= 3) ||
      (state.junks.fieryHandle >= 2) ||
      (state.junks.evilSoul >= 4) ||
      (state.junks.axePowder >= 6) ||
      (state.junks.invisibleMaterial >= 3)
    );
  }, [state.junks]);

  // Load/save warp ticket states
  useEffect(() => {
    const savedWarp = localStorage.getItem('forge_game_warp_tickets');
    if (savedWarp) {
      try {
        setWarpTickets(JSON.parse(savedWarp));
      } catch (e) {}
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('forge_game_warp_tickets', JSON.stringify(warpTickets));
  }, [warpTickets]);

  const consoleEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll console
  useEffect(() => {
    if (consoleEndRef.current) {
      consoleEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [state.history, isForging]);

  // Save game state
  useEffect(() => {
    localStorage.setItem('forge_game_easy_state', JSON.stringify(state));
  }, [state]);

  const toggleMute = () => {
    const muted = sound.toggleMute();
    setSoundMuted(muted);
    addLog(`📢 효과음이 ${muted ? '음소거' : '활성화'} 되었습니다.`);
  };

  const addLog = (message: string) => {
    setState(prev => ({
      ...prev,
      history: [...prev.history, `[${new Date().toLocaleTimeString('ko-KR', { hour12: false })}] ${message}`].slice(-60),
    }));
  };

  const currentSword: SwordInfo = SWORDS_DB[state.currentSwordLevel];
  const nextSword: SwordInfo | undefined = SWORDS_DB[state.currentSwordLevel + 1];

  // Helper check if material satisfies
  const checkMaterials = (level: number): { satisfies: boolean; feedback: string } => {
    const sInfo = SWORDS_DB[level];
    if (!sInfo.material) return { satisfies: true, feedback: '' };

    const { type, key, count } = sInfo.material;
    if (type === 'weapon') {
      const storageKey = key as keyof typeof state.storage;
      const currentCount = state.storage[storageKey] || 0;
      if (currentCount < count) {
        const weaponName = key === 'wangpu' ? '전뇌 카두케우스 (+19)' : key === 'tempest' ? '템페스트 가브리엘 (+21)' : '광속의 크로노스 (+22)';
        return { satisfies: false, feedback: `❌ 재료 무기 부족: 보관함에 [${weaponName}] ${count}자루가 필요합니다. (현재: ${currentCount}자루)` };
      }
    } else if (type === 'junk') {
      const junkKey = key as keyof JSTState;
      const currentCount = state.junks[junkKey] || 0;
      if (currentCount < count) {
        return { satisfies: false, feedback: `❌ 잡템 재료 부족: [${JUNK_NAMES[junkKey]}] ${count}개가 필요합니다. (현재: ${currentCount}개)` };
      }
    }
    return { satisfies: true, feedback: '' };
  };

  // Consume material helper
  const consumeMaterialsArgs = (level: number) => {
    const sInfo = SWORDS_DB[level];
    if (!sInfo.material) return {};

    const { type, key, count } = sInfo.material;
    if (type === 'weapon') {
      const storageKey = key as keyof typeof state.storage;
      return {
        storage: {
          ...state.storage,
          [storageKey]: Math.max(0, (state.storage[storageKey] || 0) - count),
        }
      };
    } else {
      const junkKey = key as keyof JSTState;
      return {
        junks: {
          ...state.junks,
          [junkKey]: Math.max(0, (state.junks[junkKey] || 0) - count),
        }
      };
    }
  };

  // 1. 강화 시도 (Enhance)
  const handleEnhance = () => {
    if (isForging) return;
    if (state.currentSwordLevel >= 29) {
      addLog('⚔️ 이미 전설의 최강검 [+29 영겁의 아포칼립스]을 완성하여 마스터를 초월했습니다!');
      return;
    }

    // Material Check
    const matCheck = checkMaterials(state.currentSwordLevel);
    if (!matCheck.satisfies) {
      addLog(matCheck.feedback);
      sound.playFail();
      return;
    }

    // Check Money
    if (state.money < currentSword.cost) {
      addLog(`❌ 돈이 부족합니다! 강화 비용: ${currentSword.cost.toLocaleString()}원 (현재: ${state.money.toLocaleString()}원)`);
      sound.playFail();
      return;
    }

    // Initialize forging action
    setIsForging(true);
    setForgeResult(null);

    // Play hammer metal hits
    let hitCount = 0;
    const interval = setInterval(() => {
      sound.playForge();
      hitCount++;
      if (hitCount >= 3) {
        clearInterval(interval);
        finalizeEnhancement();
      }
    }, 250);
  };

  // 1b. 연속 5회 강화 시도 (Consecutive 5 Enhancements)
  const handleConsecutiveEnhance = () => {
    if (isForging || isCombating || isConsecutive) return;
    
    // Safety checks for the very first step
    const currentLvl = stateRef.current.currentSwordLevel;
    if (currentLvl >= 29) {
      addLog('⚔️ 이미 전설의 최강검 [+29 영겁의 아포칼립스]을 완성하여 마스터를 초월했습니다!');
      return;
    }
    
    const matCheck = checkMaterials(currentLvl);
    if (!matCheck.satisfies) {
      addLog(matCheck.feedback);
      sound.playFail();
      return;
    }

    if (stateRef.current.money < SWORDS_DB[currentLvl].cost) {
      addLog(`❌ 돈이 부족합니다! 강화 비용: ${SWORDS_DB[currentLvl].cost.toLocaleString()}원 (현재: ${stateRef.current.money.toLocaleString()}원)`);
      sound.playFail();
      return;
    }

    // Start consecutive forging
    setIsConsecutive(true);
    setIsForging(true);
    setForgeResult(null);
    
    const runSingleStep = (stepNum: number) => {
      // Re-evaluate state in each step
      const currentLvl = stateRef.current.currentSwordLevel;
      const currentSw = SWORDS_DB[currentLvl];
      
      // Stop condition checking
      if (currentLvl >= 29) {
        addLog(`🎉 [+29] 전설의 최강검 달성에 성공하여 연속 강화를 중단합니다!`);
        setIsConsecutive(false);
        setIsForging(false);
        return;
      }

      // Check materials & money
      const matCheck = checkMaterials(currentLvl);
      if (!matCheck.satisfies) {
        addLog(`🛑 [재료 소진] ${matCheck.feedback} 연속 강화를 조기 중단합니다.`);
        setIsConsecutive(false);
        setIsForging(false);
        sound.playFail();
        return;
      }

      if (stateRef.current.money < currentSw.cost) {
        addLog(`🛑 [자금 부족] 강화 비용(${currentSw.cost.toLocaleString()}원)보다 보유 금액(${stateRef.current.money.toLocaleString()}원)이 부족하여 연속 강화를 조기 중단합니다.`);
        setIsConsecutive(false);
        setIsForging(false);
        sound.playFail();
        return;
      }

      addLog(`🔨 [연속 강화 ${stepNum}/5] +${currentLvl} ${currentSw.name} 강화 시도 중...`);
      sound.playForge();
      
      setTimeout(() => {
        let nextLvl = currentLvl;
        
        const isHardModeForce = currentLvl >= 26;
        const isProtectActive = stateRef.current.protectCardEnabled && !isHardModeForce;
        const protectNeeded = currentSw.protectNeed;
        const hasEnoughProtect = stateRef.current.protectCards >= protectNeeded;
        const willUseProtect = isProtectActive && protectNeeded > 0 && hasEnoughProtect;

        const randomVal = Math.random();
        const isSuccess = randomVal <= currentSw.probability;
        
        setState(prev => {
          const spent = currentSw.cost;
          const targetNextLevel = prev.currentSwordLevel + 1;
          const stats = { ...prev.statistics };
          stats.totalAttempts += 1;
          stats.totalMoneySpent += spent;

          // Consume materials
          const consumedMat = consumeMaterialsArgs(prev.currentSwordLevel);

          let updatedLevel = prev.currentSwordLevel;
          let updatedProtect = prev.protectCards;
          let newDroppedJunk = prev.droppedJunk;
          let actionResult: 'success' | 'fail' | 'destruct' = 'success';
          let outcomeMessage = '';

          if (isSuccess) {
            updatedLevel = targetNextLevel;
            nextLvl = targetNextLevel;
            stats.totalSuccesses += 1;
            stats.maxLevelReached = Math.max(stats.maxLevelReached, targetNextLevel);
            actionResult = 'success';
            outcomeMessage = `✨ [성공] 강화에 성공하여 [+${targetNextLevel} ${SWORDS_DB[targetNextLevel].name}]이(가) 되었습니다! (성공확률: ${(currentSw.probability * 100).toFixed(0)}%)`;

            if (targetNextLevel === 29) {
              setShowClearConfetti(true);
              sound.playCheer();
            } else {
              sound.playSuccess();
            }
            setForgeResult('success');
            setSuccessEffectTrigger(v => v + 1);
          } else {
            stats.totalFails += 1;
            
            if (willUseProtect) {
              updatedProtect -= protectNeeded;
              actionResult = 'fail';
              outcomeMessage = `🛡️ [실패] 강화를 실패했지만 깨짐 방지권 ${protectNeeded}개를 사용하여 소중한 검을 지켰습니다! (강화 수치 유지)`;
              sound.playFail();
              setForgeResult('fail');
            } else {
              updatedLevel = 0;
              nextLvl = 0;
              stats.totalDestructions += 1;
              actionResult = 'destruct';
              sound.playDestruct();

              if (currentSw.dropItem) {
                const dropCount = Math.floor(Math.random() * 3) + 1;
                newDroppedJunk = {
                  type: currentSw.dropItem,
                  count: dropCount
                };
                outcomeMessage = `💥 [파괴] 검이 산산조각 났습니다... [+0 낡은 단검]으로 초기화됩니다. 바닥에 [${JUNK_NAMES[currentSw.dropItem]}]이가 ${dropCount}개 떨어졌습니다!`;
              } else {
                newDroppedJunk = null;
                outcomeMessage = `💥 [파괴] 미끄러졌습니다! 보호받지 못한 소중한 검이 소멸하여 [+0 낡은 단검]으로 되돌아갔습니다.`;
              }
              setForgeResult('destruct');
            }
          }

          const timeStr = new Date().toLocaleTimeString('ko-KR', { hour12: false });
          const finalHistory = [
            ...prev.history,
            `[${timeStr}] 🔨 [연속 강화 ${stepNum}/5] [+${prev.currentSwordLevel} ${currentSw.name}] 가동... (비용: ${spent.toLocaleString()}원)`,
            `[${timeStr}] ${outcomeMessage}`
          ].slice(-60);

          return {
            ...prev,
            money: prev.money - spent,
            currentSwordLevel: updatedLevel,
            protectCards: updatedProtect,
            droppedJunk: newDroppedJunk,
            storage: consumedMat.storage ? consumedMat.storage : prev.storage,
            junks: consumedMat.junks ? consumedMat.junks : prev.junks,
            history: finalHistory,
            statistics: stats
          };
        });

        // Trigger next step or stop
        setTimeout(() => {
          if (nextLvl === 0 && !willUseProtect) {
            addLog(`❌ 검이 파괴되어 연속 강화를 중단합니다.`);
            setIsConsecutive(false);
            setIsForging(false);
            return;
          }

          if (stepNum < 5 && nextLvl < 29) {
            runSingleStep(stepNum + 1);
          } else {
            addLog(`✅ 연속 5회 강화를 성공적으로 완수했습니다!`);
            setIsConsecutive(false);
            setIsForging(false);
          }
        }, 350);

      }, 450);
    };

    runSingleStep(1);
  };

  const finalizeEnhancement = () => {
    const isHardModeForce = state.currentSwordLevel >= 26;
    const isProtectActive = state.protectCardEnabled && !isHardModeForce;
    const protectNeeded = currentSword.protectNeed;
    const hasEnoughProtect = state.protectCards >= protectNeeded;
    const willUseProtect = isProtectActive && protectNeeded > 0 && hasEnoughProtect;

    const randomVal = Math.random();
    const isSuccess = randomVal <= currentSword.probability;

    setState(prev => {
      const spent = currentSword.cost;
      const nextLevel = prev.currentSwordLevel + 1;
      const stats = { ...prev.statistics };
      stats.totalAttempts += 1;
      stats.totalMoneySpent += spent;

      // Consume materials
      const consumedMat = consumeMaterialsArgs(prev.currentSwordLevel);

      let updatedLevel = prev.currentSwordLevel;
      let updatedProtect = prev.protectCards;
      let newDroppedJunk = prev.droppedJunk;
      let actionResult: 'success' | 'fail' | 'destruct' = 'success';
      let outcomeMessage = '';

      if (isSuccess) {
        // SUCCESS
        updatedLevel = nextLevel;
        stats.totalSuccesses += 1;
        stats.maxLevelReached = Math.max(stats.maxLevelReached, nextLevel);
        actionResult = 'success';
        outcomeMessage = `✨ [성공] 강화에 성공하여 [+${nextLevel} ${SWORDS_DB[nextLevel].name}]이(가) 되었습니다! (성공확률: ${(currentSword.probability * 100).toFixed(0)}%)`;

        if (nextLevel === 29) {
          setShowClearConfetti(true);
          sound.playCheer();
        } else {
          sound.playSuccess();
        }

        // Trigger visual success ripple & particle blast
        setSuccessEffectTrigger(prev => prev + 1);
      } else {
        // FAIL
        stats.totalFails += 1;
        
        if (willUseProtect) {
          // Protected from breakage
          updatedProtect -= protectNeeded;
          actionResult = 'fail';
          outcomeMessage = `🛡️ [실패] 강화를 실패했지만 깨짐 방지권 ${protectNeeded}개를 사용하여 소중한 검을 지켰습니다! (강화 수치 유지)`;
          sound.playFail();
        } else {
          // Destruction & Initialization
          updatedLevel = 0;
          stats.totalDestructions += 1;
          actionResult = 'destruct';
          sound.playDestruct();

          // Drop item check
          if (currentSword.dropItem) {
            const dropCount = Math.floor(Math.random() * 3) + 1; // 1~3 random drop
            newDroppedJunk = {
              type: currentSword.dropItem,
              count: dropCount
            };
            outcomeMessage = `💥 [파괴] 검이 산산조각 났습니다... [+0 낡은 단검]으로 초기화됩니다. 바닥에 [${JUNK_NAMES[currentSword.dropItem]}]이가 ${dropCount}개 떨어졌습니다! [줍기] 버튼을 눌러 소중하게 획득하세요!`;
          } else {
            newDroppedJunk = null;
            outcomeMessage = `💥 [파괴] 미끄러졌습니다! 보호받지 못한 소중한 검이 소멸하여 [+0 낡은 단검]으로 되돌아갔습니다.`;
          }
        }
      }

      setForgeResult(actionResult);
      setIsForging(false);

      // Append log
      const timeStr = new Date().toLocaleTimeString('ko-KR', { hour12: false });
      const finalHistory = [
        ...prev.history,
        `[${timeStr}] 🔨 [+${prev.currentSwordLevel} ${currentSword.name}] 강화 가동... (비용: ${spent.toLocaleString()}원)`,
        `[${timeStr}] ${outcomeMessage}`
      ].slice(-60);

      // Special helper values
      const nextStorage = consumedMat.storage ? consumedMat.storage : prev.storage;
      const nextJunks = consumedMat.junks ? consumedMat.junks : prev.junks;

      return {
        ...prev,
        money: prev.money - spent,
        currentSwordLevel: updatedLevel,
        protectCards: updatedProtect,
        droppedJunk: newDroppedJunk,
        storage: nextStorage,
        junks: nextJunks,
        history: finalHistory,
        statistics: stats
      };
    });
  };

  // 2. 무기 판매 (Sell)
  const handleSell = () => {
    if (isForging) return;
    if (currentSword.sellPrice === -1) {
      addLog(`❌ [+${state.currentSwordLevel} ${currentSword.name}]은(는) 판매할 수 없는 귀중한 무기입니다!`);
      sound.playFail();
      return;
    }

    const price = currentSword.sellPrice;
    sound.playSell();
    
    setState(prev => ({
      ...prev,
      money: prev.money + price,
      currentSwordLevel: 0,
      history: [
        ...prev.history,
        `[${new Date().toLocaleTimeString('ko-KR', { hour12: false })}] 💰 [+${prev.currentSwordLevel} ${currentSword.name}]을(를) 대장간에 판매하여 ${price.toLocaleString()}원을 획득했습니다! 무기가 초기화됩니다.`
      ].slice(-60)
    }));
    addLog(`✨ 새로운 낡은 단검(+0)으로 칼질을 지속합니다.`);
  };

  // 3. 줍기 (Pick Drop Item)
  const handlePickJunk = () => {
    if (!state.droppedJunk) {
      addLog('💨 바닥에 주울 수 있는 아이템이 존재하지 않습니다.');
      sound.playFail();
      return;
    }

    const { type, count } = state.droppedJunk;
    sound.playPickup();

    setState(prev => {
      const nextJunks = { ...prev.junks };
      nextJunks[type] = (nextJunks[type] || 0) + count;

      return {
        ...prev,
        junks: nextJunks,
        droppedJunk: null,
        history: [
          ...prev.history,
          `[${new Date().toLocaleTimeString('ko-KR', { hour12: false })}] 🎒 바닥의 [${JUNK_NAMES[type]}] ${count}개를 주머니에 고이 주워 담았습니다!`
        ].slice(-60)
      };
    });
  };

  // 4. 보관함에 보관하기 (Store in Storage)
  const handleStoreSword = () => {
    if (isForging) return;
    if (!currentSword.isStorageRequired) {
      addLog(`❌ [+${state.currentSwordLevel} ${currentSword.name}]은(는) 보관이 불가능하거나 강화 목적의 보관 필수 장비가 아닙니다. 장갑검 전용칸입니다!`);
      sound.playFail();
      return;
    }

    sound.playBuy();
    setState(prev => {
      const nextStorage = { ...prev.storage };
      let key: keyof typeof prev.storage = 'wangpu';
      let storageName = '';

      if (prev.currentSwordLevel === 19) {
        key = 'wangpu';
        storageName = '전뇌 카두케우스 (+19)';
      } else if (prev.currentSwordLevel === 21) {
        key = 'tempest';
        storageName = '템페스트 가브리엘 (+21)';
      } else if (prev.currentSwordLevel === 22) {
        key = 'sharp';
        storageName = '광속의 크로노스 (+22)';
      }

      nextStorage[key] += 1;

      return {
        ...prev,
        storage: nextStorage,
        currentSwordLevel: 0,
        history: [
          ...prev.history,
          `[${new Date().toLocaleTimeString('ko-KR', { hour12: false })}] 📦 [+${prev.currentSwordLevel} ${currentSword.name}]을 무기 보관함으로 전송 보관했습니다! 비어있는 자리에 [+0 낡은 단검]을 장착합니다.`
        ].slice(-60)
      };
    });
  };

  // 4b. 임시보관 및 보관검꺼내기
  const handleTempStore = () => {
    if (isForging) return;
    if (state.tempStorage.length >= 5) {
      addLog(`❌ 이미 임시 보관함에 검이 5자루 가득 찬 상태입니다! 기존 보관검을 꺼내기 전까지 추가 보관은 불가능합니다.`);
      sound.playFail();
      return;
    }

    sound.playBuy();
    setState(prev => {
      const swordToStore = SWORDS_DB[prev.currentSwordLevel];
      const newTempStorage = [...prev.tempStorage, {
        level: prev.currentSwordLevel,
        name: swordToStore.name,
      }];
      return {
        ...prev,
        tempStorage: newTempStorage,
        currentSwordLevel: 0,
        history: [
          ...prev.history,
          `[${new Date().toLocaleTimeString('ko-KR', { hour12: false })}] 📦 [임시보관] 장착 중이던 [+${prev.currentSwordLevel} ${swordToStore.name}]을 임시 보관함(${newTempStorage.length}/5)에 안전하게 임시 보관하였습니다. 현재 무기는 [+0 낡은 단검]으로 초기화됩니다.`
        ].slice(-60)
      };
    });
  };

  const handleTempRetrieve = (index?: number) => {
    if (isForging) return;
    if (state.tempStorage.length === 0) {
      addLog(`❌ 임시 보관함이 비어있습니다. 꺼낼 보관검이 없습니다!`);
      sound.playFail();
      return;
    }

    const targetIdx = index !== undefined ? index : state.tempStorage.length - 1;
    if (targetIdx < 0 || targetIdx >= state.tempStorage.length) {
      addLog(`❌ 유효하지 않은 보관함 슬롯 위치입니다: ${targetIdx + 1}`);
      sound.playFail();
      return;
    }

    sound.playSuccess();
    setState(prev => {
      if (prev.tempStorage.length === 0) return prev;
      const retrieved = prev.tempStorage[targetIdx];
      const currentLevel = prev.currentSwordLevel;
      const currentSw = SWORDS_DB[currentLevel];
      
      let newTempStorage = [...prev.tempStorage];
      let outcomeMessage = '';

      if (currentLevel === 0) {
        // Just retrieve and remove from storage
        newTempStorage = prev.tempStorage.filter((_, i) => i !== targetIdx);
        outcomeMessage = `[${new Date().toLocaleTimeString('ko-KR', { hour12: false })}] 📦 [보관검꺼내기] 임시 보관함의 ${targetIdx + 1}번 슬롯에 있던 [+${retrieved.level} ${retrieved.name}]을 무사히 꺼내어 다시 장착했습니다! (남은 보관검: ${newTempStorage.length}/5)`;
      } else {
        // Swap currently equipped sword with stored sword!
        newTempStorage[targetIdx] = {
          level: currentLevel,
          name: currentSw.name,
        };
        outcomeMessage = `[${new Date().toLocaleTimeString('ko-KR', { hour12: false })}] 🔄 [보관검교환] 장착 중이던 [+${currentLevel} ${currentSw.name}]을 임시 보관함의 ${targetIdx + 1}번 슬롯에 보관하고, 기존 슬롯에 있던 [+${retrieved.level} ${retrieved.name}]을 꺼내어 교환 장착했습니다!`;
      }

      return {
        ...prev,
        currentSwordLevel: retrieved.level,
        tempStorage: newTempStorage,
        history: [
          ...prev.history,
          outcomeMessage
        ].slice(-60)
      };
    });
  };

  // 4bb. 보관함에서 무기 꺼내기 (Withdraw from main material storage)
  const handleWithdrawFromStorage = (key: 'wangpu' | 'tempest' | 'sharp') => {
    if (isForging || isCombating) return;
    if (state.storage[key] <= 0) {
      addLog(`❌ 보관 중인 해당 장비가 없습니다.`);
      sound.playFail();
      return;
    }

    const targetLevel = key === 'wangpu' ? 19 : key === 'tempest' ? 21 : 22;
    const targetSword = SWORDS_DB[targetLevel];

    // Check if hand is empty (level 0)
    if (state.currentSwordLevel === 0) {
      setState(prev => {
        const nextStorage = { ...prev.storage };
        nextStorage[key] -= 1;
        return {
          ...prev,
          storage: nextStorage,
          currentSwordLevel: targetLevel,
          history: [
            ...prev.history,
            `[${new Date().toLocaleTimeString('ko-KR', { hour12: false })}] 📦 [보관함 꺼내기] 보관되어 있던 [+${targetLevel} ${targetSword.name}]을 무사히 꺼내어 장착했습니다!`
          ].slice(-60)
        };
      });
      sound.playPickup();
    } else {
      // If hand is not empty, check if we can store it in tempStorage
      if (state.tempStorage.length >= 5) {
        addLog(`❌ 손에 이미 장착한 장비가 있고, 임시 보관함도 가득 차서 보관함에서 꺼낼 수 없습니다. 임시 보관함을 비워주세요.`);
        sound.playFail();
        return;
      }

      setState(prev => {
        const nextStorage = { ...prev.storage };
        nextStorage[key] -= 1;
        const newTempStorage = [...prev.tempStorage, {
          level: targetLevel,
          name: targetSword.name,
        }];
        return {
          ...prev,
          storage: nextStorage,
          tempStorage: newTempStorage,
          history: [
            ...prev.history,
            `[${new Date().toLocaleTimeString('ko-KR', { hour12: false })}] 📦 [보관함 꺼내기] 보관되어 있던 [+${targetLevel} ${targetSword.name}]을 임시 보관함으로 꺼냈습니다!`
          ].slice(-60)
        };
      });
      sound.playPickup();
    }
  };
  
  // 4c. 전투 시스템 ("전투하기")
  const STAGES = [
    {
      index: 1,
      name: '수련용 목각 인형터',
      minLevel: 0,
      monster: '초보 수련 목각 인형',
      boss: '철갑 무장 샌드백',
      reward: 12000,
      getWinRate: (level: number) => 1.00,
      introLogs: [
        '🪵 초보 모험가를 위해 마련된 평화로운 대장간 뒷마당 수련장입니다. 움직이지 않는 목각 인형들이 줄지어 서있습니다.',
        '🥊 대장간 숙련가들이 견고하게 특수 제작한 철갑 무장 샌드백이 단단한 위용을 자랑하며 정면에 고정되어 있습니다!'
      ],
    },
    {
      index: 2,
      name: '바람의 슬라임 동굴',
      minLevel: 2,
      monster: '꼬마 바람 슬라임',
      boss: '거대 바람 슬라임 킹',
      reward: 35000,
      getWinRate: (level: number) => (level < 4 ? 0.75 : 0.98),
      introLogs: [
        '💧 동굴 입구에서부터 끈적이고 말랑말랑한 바람 슬라임들이 통통 튀며 가벼운 미풍과 함께 날아옵니다!',
        '👑 바람의 에너지를 듬뿍 축적해 푸른빛을 발산하는 엄청난 크기의 거대 바람 슬라임 킹이 길을 가로막고 통통 튑니다!'
      ],
    },
    {
      index: 3,
      name: '타오르는 가고일 절벽',
      minLevel: 4,
      monster: '가고일 주니어',
      boss: '지옥불 성수 가고일',
      reward: 85000,
      getWinRate: (level: number) => (level < 6 ? 0.65 : 0.95),
      introLogs: [
        '⛰️ 붉은 마그마 연기가 조금씩 뿜어져 나오는 절벽 틈새에서 날카로운 날개짓 소리와 함께 아기 가고일들이 활공합니다!',
        '👿 화강암처럼 단단한 온몸이 시뻘건 지옥불로 가득 차 눈을 번뜩이는 가고일 군주가 절벽 위에서 급강하하며 울부짖습니다!'
      ],
    },
    {
      index: 4,
      name: '고블린 숲',
      minLevel: 5,
      monster: '일반 고블린',
      boss: '족장 타우',
      reward: 180000,
      getWinRate: (level: number) => (level < 10 ? 0.60 : 0.95),
      introLogs: [
        '🌲 음산한 나무숲 사이로 고블린 군단이 소리를 지르며 모습을 드러냅니다!',
        '⚔️ 족장 타우가 거대한 도끼를 좌우로 휘두르며 자욱한 안개 속에서 돌진해 옵니다!'
      ],
    },
    {
      index: 5,
      name: '저주받은 늑대 골짜기',
      minLevel: 8,
      monster: '그림자 붉은 늑대',
      boss: '사악한 한밤의 하울',
      reward: 550000,
      getWinRate: (level: number) => (level < 11 ? 0.55 : 0.92),
      introLogs: [
        '🐺 달빛조차 스며들지 못하는 어둠 속에서 가슴 찢어지는 늑대의 하울링 소리와 함께 그림자 늑대떼가 포위해옵니다!',
        '💀 이마에 불길한 저주의 해골 낙인이 찍혀있으며 은빛 털을 날리며 돌진하는 거대 늑대 왕 하울이 날카로운 발톱을 세웁니다!'
      ],
    },
    {
      index: 6,
      name: '타락한 정령의 기단',
      minLevel: 11,
      monster: '오염된 하급 불빛정령',
      boss: '붕괴된 정령왕 라데온',
      reward: 1300000,
      getWinRate: (level: number) => (level < 14 ? 0.52 : 0.90),
      introLogs: [
        '✨ 깨끗했던 기단이 불길하게 오염되어, 푸른빛 대신 자색 광폭 에너지를 마구 뿜어내는 정령들이 사방을 메웁니다!',
        '🌪️ 대지와 바위, 바람의 잔해가 한데 엉켜 기이하게 폭주하는 정령왕 라데온이 거센 폭풍우를 동반하며 일어섭니다!'
      ],
    },
    {
      index: 7,
      name: '불타는 그락카락',
      minLevel: 13,
      monster: '화염의 킹고블린',
      boss: '비노슈',
      reward: 2500000,
      getWinRate: (level: number) => (level < 16 ? 0.50 : 0.90),
      introLogs: [
        '🔥 활활 불타오르는 대지 위로 화염의 킹고블린들이 화염구를 날리며 포위해 옵니다!',
        '🧙‍♀️ 비노슈가 붉고 화려한 지팡이로 거대한 마법진을 그린 뒤 하늘에서 운석들을 내리꽂습니다!'
      ],
    },
    {
      index: 8,
      name: '얼어붙은 얼음 궁전',
      minLevel: 16,
      monster: '궁전 한빙 해골병사',
      boss: '얼음 여왕 케라하',
      reward: 12000000,
      getWinRate: (level: number) => (level < 18 ? 0.45 : 0.88),
      introLogs: [
        '❄️ 숨결조차 하얗게 얼어붙는 차가운 얼음 궁전의 문이 열리고, 서리 낀 대검을 든 해골병사들이 차갑게 걸어옵니다!',
        '❄️🧙‍♀️ 푸른 머릿결을 휘날리며 눈꽃 결정을 조종하는 사가각 얼음 여왕 케라하가 전방을 향해 무한한 한파를 발산합니다!'
      ],
    },
    {
      index: 9,
      name: '비명굴',
      minLevel: 19,
      monster: '스컬 케인',
      boss: '거대 누골',
      reward: 60000000,
      getWinRate: (level: number) => (level < 23 ? 0.40 : 0.85),
      introLogs: [
        '🦴 가느다란 비명 소리와 함께 어둠 속에서 눈동자가 번쩍이는 스컬 케인이 대검을 질질 끌며 사가각 다가옵니다!',
        '🐛 사나운 촉수들이 사방으로 요동치며 이빨이 전면 배치된 기괴한 거대 누골이 땅을 가르고 포효를 내지릅니다!'
      ],
    },
    {
      index: 10,
      name: '혼돈의 차원 포털',
      minLevel: 21,
      monster: '차원 폭주 플라스마',
      boss: '혼돈의 가고일 바르가스',
      reward: 160000000,
      getWinRate: (level: number) => (level < 22 ? 0.38 : 0.82),
      introLogs: [
        '🌌 시공의 뒤틀림을 통해 미지의 번개가 내려치며 파동치는 플라스마 괴물들이 차원문 밖으로 쏟아져 나옵니다!',
        '🧿 시공간의 법칙을 깨뜨리며 붉은 레이저와 파동권으로 침입자들을 지워버리려는 가고일 바르가스가 대지 위로 하강합니다!'
      ],
    },
    {
      index: 11,
      name: '폭룡왕의 바칼 궁전',
      minLevel: 23,
      monster: '화염의 숨결 리오트',
      boss: '폭룡왕 바칼',
      reward: 450000000,
      getWinRate: (level: number) => (level < 25 ? 0.35 : 0.80),
      introLogs: [
        '🔥 사방을 삼켜버릴 듯 붉게 타오르는 용족 군단과 화염의 숨결 리오트가 울부짖으며 하늘에서 공습을 개시합니다!',
        '🐉 거대한 날갯짓과 함께 대지 전체를 짓밟으며 지옥과도 같은 화염 브레스를 내뿜는 폭룡왕 바칼이 분노합니다!'
      ],
    },
    {
      index: 12,
      name: '시공간 왜곡의 차원의 틈',
      minLevel: 26,
      monster: '이계의 왜곡된 망령',
      boss: '검은 질병의 디레지에',
      reward: 2000000000,
      getWinRate: (level: number) => (level < 28 ? 0.30 : 0.75),
      introLogs: [
        '🌌 시공간이 붕괴하며 갈라진 차원의 왜곡된 틈새 속에서 기괴하고 거대한 망령군단이 폭풍처럼 밀려옵니다!',
        '🧬 독기와 유독성 기류를 마구 방출하며 형체를 가늠하기 힘든 디레지에가 나락의 무한한 질병으로 참전을 경고합니다!'
      ],
    },
    {
      index: 13,
      name: '용암과 재의 안톤 저지선',
      minLevel: 28,
      monster: '화염의 구석기 용암괴물',
      boss: '탐식의 대화산 안톤',
      reward: 12000000000,
      getWinRate: (level: number) => (level < 29 ? 0.25 : 0.70),
      introLogs: [
        '🌋 끓어오르는 대화산의 붉은 용암액 속에서 타오르는 마그마 암석 용암괴물들이 대열을 갖추며 맹습합니다!',
        '🐢 산과 같은 등껍질을 한 채 대지 전체를 진동시키는 초거대 사도 안톤이 전방위 대폭발을 일으켜 재앙을 선사합니다!'
      ],
    }
  ];

  const handleCombat = (stageNum: number, chosenSwordIndex?: number) => {
    if (isForging || isCombating) return;

    const stage = STAGES.find(s => s.index === stageNum);
    if (!stage) {
      addLog(`❌ 존재하지 않는 스테이지 번호입니다.`);
      sound.playFail();
      return;
    }

    // Determine which sword to use
    let swordIdx = chosenSwordIndex;
    if (swordIdx === undefined) {
      // Find qualifying swords in tempStorage
      const candidates = state.tempStorage
        .map((s, idx) => ({ ...s, idx }))
        .filter(s => s.level >= stage.minLevel);
        
      if (candidates.length === 0) {
        addLog(`❌ [진입 실패] [${stage.name}] 진입 조건(+${stage.minLevel}강 이상)을 충족하는 무기가 임시 보관함에 없습니다!`);
        sound.playFail();
        return;
      }
      
      // Pick the best of them (highest level)
      candidates.sort((a, b) => b.level - a.level);
      swordIdx = candidates[0].idx;
    }

    const sword = state.tempStorage[swordIdx];
    if (!sword) {
      addLog(`❌ 유효하지 않은 검 선택입니다.`);
      sound.playFail();
      return;
    }

    if (sword.level < stage.minLevel) {
      addLog(`❌ [+${sword.level} ${sword.name}] 검으로는 [${stage.name}] 진입 조건을 충족할 수 없습니다. (최소 +${stage.minLevel}강 이상 필요)`);
      sound.playFail();
      return;
    }

    // Start combat
    setIsCombating(true);

    // 1. Change Map Name & log startup
    setState(prev => ({
      ...prev,
      currentMap: stage.name,
      history: [
        ...prev.history,
        `[${new Date().toLocaleTimeString('ko-KR', { hour12: false })}] 🗺️ [전투 돌입] 대장간에서 [${stage.name}]으로 신속하게 진입했습니다!`
      ].slice(-60)
    }));
    sound.playForge();

    // Staged timeout logs for cinematic immersion
    setTimeout(() => {
      addLog(`⚔️ 모험가가 [+${sword.level} ${sword.name}]을(를) 힘차게 휘두르며 전방에 포진한 [${stage.monster}]을 사냥하기 시작합니다!`);
      stage.introLogs.forEach((intro, i) => {
        setTimeout(() => {
          addLog(intro);
          // Camera shake disabled per user request to stabilizer the viewpoint
          // setShakeScreen(true);
          // setTimeout(() => setShakeScreen(false), 200);
        }, (i + 1) * 350);
      });
    }, 400);

    // Final battle clash calculations
    setTimeout(() => {
      const winRate = stage.getWinRate(sword.level);
      const isWin = Math.random() < winRate;
      const rollNum = Math.floor(Math.random() * 100) + 1;

      if (isWin) {
        sound.playSuccess();
        setState(prev => {
          const newMoney = prev.money + stage.reward;
          return {
            ...prev,
            money: newMoney,
            currentMap: '대장간',
            history: [
              ...prev.history,
              `[${new Date().toLocaleTimeString('ko-KR', { hour12: false })}] 🎲 (주사위 판정: ${rollNum} / 승리 조건: ${(winRate * 100).toFixed(0)}% 이하)`,
              `[${new Date().toLocaleTimeString('ko-KR', { hour12: false })}] 🎉 [전투 승리] 보스 [${stage.boss}]의 숨통을 단숨에 끊었습니다! 전리품으로 골드 [${stage.reward.toLocaleString()}원]을 획득하고 안전하게 대장간으로 복귀했습니다.`
            ].slice(-60)
          };
        });
      } else {
        sound.playFail();
        setState(prev => {
          return {
            ...prev,
            currentMap: '대장간',
            history: [
              ...prev.history,
              `[${new Date().toLocaleTimeString('ko-KR', { hour12: false })}] 🎲 (주사위 판정: ${rollNum} / 승리 조건: ${(winRate * 100).toFixed(0)}% 이하)`,
              `[${new Date().toLocaleTimeString('ko-KR', { hour12: false })}] 💀 [전투 패배] 수많은 부하 몬스터들과 보스 [${stage.boss}]의 무자비한 공격에 압도당했습니다! 검이 파괴되지는 않았으나 보상을 얻지 못한 채 대장간으로 호되게 패주했습니다...`
            ].slice(-60)
          };
        });
      }
      setIsCombating(false);
    }, 1800);
  };

  const handleCombatRef = useRef(handleCombat);
  useEffect(() => {
    handleCombatRef.current = handleCombat;
  }, [handleCombat]);

  useEffect(() => {
    if (isAutoCombat && !isCombating && autoCombatStageNum !== null) {
      const stage = STAGES.find(s => s.index === autoCombatStageNum);
      if (stage) {
        // Find best usable sword in tempStorage
        const bestUsableSword = [...state.tempStorage]
          .filter(itm => itm.level >= stage.minLevel)
          .sort((a, b) => b.level - a.level)[0];

        if (bestUsableSword && !isForging) {
          const timer = setTimeout(() => {
            if (isAutoCombatRef.current && !isCombatingRef.current && !isForgingRef.current) {
              handleCombatRef.current(autoCombatStageNum);
            }
          }, 600); // 600ms delay for visual pacing
          return () => clearTimeout(timer);
        } else {
          // No usable sword or forging started
          setIsAutoCombat(false);
          addLog(`[자동 전투] 🛑 더 이상 해당 스테이지(+${stage.minLevel}강 이상)에 출격 가능한 장비가 보관함에 없어 자동 전투가 중단되었습니다.`);
          sound.playFail();
        }
      } else {
        setIsAutoCombat(false);
      }
    }
  }, [isAutoCombat, isCombating, autoCombatStageNum, state.tempStorage, isForging]);

  // 5. 상점 구매 (Shop Buy)
  const handleBuyShop = (itemKey: 'protect_1' | 'protect_3' | 'warp_9' | 'warp_13' | 'warp_14' | 'warp_15', cost: number) => {
    if (isForging || isCombating) return;
    if (state.money < cost) {
      addLog(`❌ 돈이 모자라 상점 물건을 구매할 수 없습니다! (필요금액: ${cost.toLocaleString()}원)`);
      sound.playFail();
      return;
    }

    sound.playBuy();
    setState(prev => {
      let updatedProtect = prev.protectCards;
      let logMsg = '';

      if (itemKey === 'protect_1') {
        updatedProtect += 1;
        logMsg = `🛡️ 깨짐 방지권 1개를 상점에서 ${cost.toLocaleString()}원에 구매했습니다.`;
      } else if (itemKey === 'protect_3') {
        updatedProtect += 3;
        logMsg = `🛡️ 깨짐 방지권 3개를 상점에서 ${cost.toLocaleString()}원에 구매했습니다.`;
      }

      return {
        ...prev,
        money: prev.money - cost,
        protectCards: updatedProtect,
        history: [...prev.history, `[${new Date().toLocaleTimeString('ko-KR', { hour12: false })}] ${logMsg}`].slice(-60)
      };
    });

    // Handle Warp Tickets inside inner React tracking
    if (itemKey.startsWith('warp_')) {
      const targetLvl = parseInt(itemKey.split('_')[1]);
      setWarpTickets(prev => ({
        ...prev,
        [targetLvl]: prev[targetLvl] + 1
      }));
      setState(prev => ({
        ...prev,
        money: prev.money - cost,
        history: [...prev.history, `[${new Date().toLocaleTimeString('ko-KR', { hour12: false })}] 🎟️ +${targetLvl}강 워프권 1장을 ${cost.toLocaleString()}원에 구매했습니다. 인벤토리에서 즉시 사용이 가능합니다.`].slice(-60)
      }));
    }
  };

  // Use Warp Ticket
  const handleUseWarp = (level: number) => {
    if (isForging || isCombating) return;
    if (warpTickets[level] <= 0) {
      addLog('❌ 사용할 수 있는 해당 등급 워프권 티켓이 없습니다.');
      sound.playFail();
      return;
    }

    setWarpTickets(prev => ({
      ...prev,
      [level]: prev[level] - 1
    }));

    sound.playSuccess();
    setState(prev => {
      const targetSword = SWORDS_DB[level];
      const timeStr = new Date().toLocaleTimeString('ko-KR', { hour12: false });
      return {
        ...prev,
        currentSwordLevel: level,
        history: [
          ...prev.history,
          `[${timeStr}] 🎟️ 워프권 사용! 장착된 무기가 즉시 [+${level} ${targetSword.name}] 최고급 등급으로 순간 이동 장착되었습니다!`
        ].slice(-60)
      };
    });
  };

  // 6. 조합소 교환 (Alchemy Forge)
  const handleCombine = (recipeId: number) => {
    if (isForging || isCombating) return;
    
    let isSatisfied = false;
    let desc = '';
    let actionEffect = () => {};

    switch (recipeId) {
      case 1: // 국적불분명 철조각 5개 -> 깨짐 방지권 1개
        isSatisfied = state.junks.ironPiece >= 5;
        desc = '국적불분명 철조각 5개 ➡️ 깨짐 방지권 1개';
        actionEffect = () => {
          setState(prev => ({
            ...prev,
            junks: { ...prev.junks, ironPiece: prev.junks.ironPiece - 5 },
            protectCards: prev.protectCards + 1,
          }));
        };
        break;
      case 2: // 타우의 뼈 부스러기 3개 -> 깨짐 방지권 1개
        isSatisfied = state.junks.tauBone >= 3;
        desc = '타우의 뼈 부스러기 3개 ➡️ 깨짐 방지권 1개';
        actionEffect = () => {
          setState(prev => ({
            ...prev,
            junks: { ...prev.junks, tauBone: prev.junks.tauBone - 3 },
            protectCards: prev.protectCards + 1,
          }));
        };
        break;
      case 3: // 빛 바랜 형광물질 2개 -> +13강 불꽃 마검 1개 (장착 즉시)
        isSatisfied = state.junks.fluorescence >= 2;
        desc = '빛 바랜 형광물질 2개 ➡️ +13강 불꽃 마검 소환';
        actionEffect = () => {
          setState(prev => ({
            ...prev,
            junks: { ...prev.junks, fluorescence: prev.junks.fluorescence - 2 },
            currentSwordLevel: 13,
          }));
        };
        break;
      case 4: // 스위스산 철조각 3개 -> 깨짐 방지권 2개
        isSatisfied = state.junks.swissIron >= 3;
        desc = '스위스산 철조각 3개 ➡️ 깨짐 방지권 2개';
        actionEffect = () => {
          setState(prev => ({
            ...prev,
            junks: { ...prev.junks, swissIron: prev.junks.swissIron - 3 },
            protectCards: prev.protectCards + 2,
          }));
        };
        break;
      case 5: // 불꽃마검 손잡이 2개 -> +16강 투명 검 1개 (장착 즉시)
        isSatisfied = state.junks.fieryHandle >= 2;
        desc = '불꽃마검 손잡이 2개 ➡️ +16강 투명 검 소환';
        actionEffect = () => {
          setState(prev => ({
            ...prev,
            junks: { ...prev.junks, fieryHandle: prev.junks.fieryHandle - 2 },
            currentSwordLevel: 16,
          }));
        };
        break;
      case 6: // 망각의 나락에서 울부짖는 원혼 4개 -> 깨짐 방지권 4개
        isSatisfied = state.junks.evilSoul >= 4;
        desc = '망각의 나락에서 울부짖는 원혼 4개 ➡️ 깨짐 방지권 4개';
        actionEffect = () => {
          setState(prev => ({
            ...prev,
            junks: { ...prev.junks, evilSoul: prev.junks.evilSoul - 4 },
            protectCards: prev.protectCards + 4,
          }));
        };
        break;
      case 7: // 망각의 나락에서 울부짖는 원혼 6개 -> +19강 전뇌 카두케우스 1개 (장착 즉시)
        isSatisfied = state.junks.evilSoul >= 6;
        desc = '망각의 나락에서 울부짖는 원혼 6개 ➡️ +19강 전뇌 카두케우스 소환';
        actionEffect = () => {
          setState(prev => ({
            ...prev,
            junks: { ...prev.junks, evilSoul: prev.junks.evilSoul - 6 },
            currentSwordLevel: 19,
          }));
        };
        break;
      case 8: // 도끼 가루 6개 -> 깨짐 방지권 10개
        isSatisfied = state.junks.axePowder >= 6;
        desc = '도끼 가루 6개 ➡️ 깨짐 방지권 10개';
        actionEffect = () => {
          setState(prev => ({
            ...prev,
            junks: { ...prev.junks, axePowder: prev.junks.axePowder - 6 },
            protectCards: prev.protectCards + 10,
          }));
        };
        break;
      case 9: // 투명 물질 3개 -> 깨짐 방지권 9개
        isSatisfied = state.junks.invisibleMaterial >= 3;
        desc = '투명 물질 3개 ➡️ 깨짐 방지권 9개';
        actionEffect = () => {
          setState(prev => ({
            ...prev,
            junks: { ...prev.junks, invisibleMaterial: prev.junks.invisibleMaterial - 3 },
            protectCards: prev.protectCards + 9,
          }));
        };
        break;
    }

    if (!isSatisfied) {
      addLog(`❌ 연성 재료가 부족하여 비급 조합을 실패했습니다! [${desc}]`);
      sound.playFail();
      return;
    }

    sound.playSuccess();
    actionEffect();
    addLog(`✨ [조합 성공] 비급 연성 기운이 솟아나 특수 아이템 [${desc}]을 빚어냈습니다!`);
  };

  // Reset Game Confirmation
  const handleResetGame = () => {
    if (window.confirm('정말로 모든 강화 정보와 자금을 초기화하고 새롭게 대장장이 인생을 시작하겠습니까?')) {
      setState(INITIAL_STATE);
      setWarpTickets({ 9: 0, 13: 0, 14: 0, 15: 0 });
      localStorage.removeItem('forge_game_easy_state');
      localStorage.removeItem('forge_game_warp_tickets');
      sound.playDestruct();
      alert('대장간의 모든 가마솥과 금고가 초기화되었습니다!');
    }
  };

  // Restore Game State from external file
  const handleRestoreState = (loadedState: GameState, loadedWarpTickets?: { [key: number]: number }) => {
    setState(loadedState);
    if (loadedWarpTickets) {
      setWarpTickets(loadedWarpTickets);
      localStorage.setItem('forge_game_warp_tickets', JSON.stringify(loadedWarpTickets));
    }
    localStorage.setItem('forge_game_easy_state', JSON.stringify(loadedState));
  };

  // Keyboard shortcut for forging, picking junk
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (document.activeElement?.tagName === 'INPUT') return; // Ignore on console input active
      if (isForging || isCombating) return; // Block on active actions
      if (e.code === 'Space') {
        e.preventDefault();
        handleEnhance();
      } else if (e.code === 'KeyC') {
        e.preventDefault();
        handleConsecutiveEnhance();
      } else if (e.code === 'KeyF' || e.code === 'KeyG') {
        e.preventDefault();
        handlePickJunk();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [state, isForging, isCombating]);

  // Console Command Handling
  const handleConsoleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cmd = consoleInput.trim();
    setConsoleInput('');

    if (!cmd) return;

    addLog(`> ${cmd}`);

    if (isForging || isCombating) {
      addLog(`⚠️ 현재 다른 작업(강화 또는 전투 연출)이 진행 중이어서 명령을 내릴 수 없습니다.`);
      sound.playFail();
      return;
    }

    const normalizedInput = cmd.replace(/\s+/g, ' ');
    const args = normalizedInput.split(' ');
    const lowerCmd = args[0].toLowerCase();
    const fullLower = normalizedInput.toLowerCase();

    let isHandled = false;

    if (['파일', '다운로드', '파일다운로드', '백업', '내보내기', '소스코드', 'zip'].includes(lowerCmd)) {
      setShowFileModal(true);
      addLog('📁 파일 다운로드 및 데이터 백업 창을 열었습니다.');
      isHandled = true;
    } else if (lowerCmd === '강화') {
      handleEnhance();
      isHandled = true;
    } else if (['연속강화', '연속5강', '연속5회강화'].includes(lowerCmd)) {
      handleConsecutiveEnhance();
      isHandled = true;
    } else if (lowerCmd === '판매') {
      handleSell();
      isHandled = true;
    } else if (lowerCmd === '줍기') {
      handlePickJunk();
      isHandled = true;
    } else if (['보관하기', '보관', '검 보관하기'].includes(lowerCmd)) {
      handleStoreSword();
      isHandled = true;
    } else if (['임시보관', '임시 보관'].includes(fullLower)) {
      handleTempStore();
      isHandled = true;
    } else if (fullLower.startsWith('보관검꺼내기') || fullLower.startsWith('보관검 꺼내기') || fullLower.startsWith('꺼내기')) {
      // Find digit argument if any
      const match = fullLower.match(/\d+/);
      const idx = match ? parseInt(match[0]) - 1 : undefined;
      handleTempRetrieve(idx);
      isHandled = true;
    } else if (fullLower.startsWith('전투하기') || fullLower.startsWith('전투')) {
      const match = fullLower.match(/\d+/);
      const stageNum = match ? parseInt(match[0]) : undefined;
      
      if (stageNum !== undefined) {
        if (stageNum >= 1 && stageNum <= STAGES.length) {
          handleCombat(stageNum);
        } else {
          addLog(`❌ 존재하지 않는 스테이지 번호입니다: ${stageNum}. (1 ~ ${STAGES.length} 스테이지까지 이용 가능)`);
          sound.playFail();
        }
      } else {
        const bestWeapon = state.tempStorage.length > 0 ? [...state.tempStorage].sort((a, b) => b.level - a.level)[0] : null;
        if (!bestWeapon) {
          addLog(`❌ [전투 불가] 임시 보관함에 전투용 검이 없어 전투에 진입할 수 없습니다! '임시보관' 명령어로 장착 중인 검을 보관함에 넣으세요.`);
          sound.playFail();
        } else {
          const qualifiedStages = [...STAGES]
            .filter(stg => bestWeapon.level >= stg.minLevel)
            .sort((a, b) => b.index - a.index);
          
          if (qualifiedStages.length > 0) {
            handleCombat(qualifiedStages[0].index);
          } else {
            addLog(`❌ 보유 중인 임시 보관된 검 [+${bestWeapon.level} ${bestWeapon.name}]은(는) 가용할 수 있는 최하위 던전의 입장 조건조차 미달합니다.`);
            sound.playFail();
          }
        }
      }
      isHandled = true;
    } else if (['상점', '상점가기'].includes(lowerCmd)) {
      setActiveTab('shop');
      addLog('🛒 상점 탭으로 신속하게 이동했습니다.');
      isHandled = true;
    } else if (['조합소', '조합소가기', '조합'].includes(lowerCmd)) {
      setActiveTab('alchemy');
      addLog('🧪 전설의 조합소 연성지 탭으로 이동했습니다.');
      isHandled = true;
    } else if (lowerCmd === '도움말' || lowerCmd === 'help') {
      addLog('📖 명령어 리스트: [강화] / [연속5강] / [판매] / [임시보관] / [보관검꺼내기(슬롯번호)] / [전투하기(스테이지)] / [줍기] / [보관] / [상점] / [조합소] / [도움말]');
      isHandled = true;
    }

    if (!isHandled) {
      addLog(`❓ 알 수 없는 명령어입니다: "${cmd}". 도움말을 입력해보세요.`);
      sound.playFail();
    }
  };

  // String formatting formatting matches the required exact UI structure!
  const getRequiredAsciiUI = () => {
    const formatMoney = (val: number) => val.toLocaleString();
    const storedWeapons = [
      state.storage.wangpu > 0 && `전뇌 카두케우스(+19) ${state.storage.wangpu}자루`,
      state.storage.tempest > 0 && `템페스트 가브리엘(+21) ${state.storage.tempest}자루`,
      state.storage.sharp > 0 && `광속의 크로노스(+22) ${state.storage.sharp}자루`,
    ].filter(Boolean).join(', ');

    const tempStorageStr = state.tempStorage.length > 0 
      ? state.tempStorage.map(item => `[+${item.level} ${item.name}]`).join(', ')
      : '[비어있음]';

    return `====================================
🗺️ 현재 위치: [${state.currentMap}]
🗡️ 강화용 검: [+${state.currentSwordLevel} ${currentSword.name}]
📦 임시 보관함 (전투용): ${tempStorageStr}
💰 보유 자금: ${formatMoney(state.money)}원 | 🛡️ 깨짐 방지권: ${state.protectCards}개
🎒 재료 보관함: [${storedWeapons || '없음'}]
💎 잡템 현황: 철조각(${state.junks.ironPiece}), 뼈(${state.junks.tauBone}), 형광(${state.junks.fluorescence}), 스위스(${state.junks.swissIron}), 손잡이(${state.junks.fieryHandle}), 영혼(${state.junks.evilSoul}), 도끼(${state.junks.axePowder}), 투명(${state.junks.invisibleMaterial})
====================================
선택 가능: [강화] [판매] [임시보관] [보관검꺼내기] [전투하기] [상점가기] [조합소가기]`;
  };

  // Determine fancy color based on level
  const getSwordLevelColor = (lvl: number) => {
    if (lvl === 0) return 'text-zinc-400 drop-shadow-sm';
    if (lvl < 6) return 'text-emerald-400 font-medium drop-shadow-sm';
    if (lvl < 11) return 'text-cyan-400 font-medium drop-shadow-[0_0_2px_rgba(34,211,238,0.5)]';
    if (lvl < 16) return 'text-indigo-400 font-semibold drop-shadow-[0_0_3px_rgba(129,140,248,0.6)]';
    if (lvl < 20) return 'text-pink-400 font-bold drop-shadow-[0_0_6px_rgba(244,114,182,0.8)]';
    if (lvl < 25) return 'text-orange-400 font-extrabold tracking-wide drop-shadow-[0_0_8px_rgba(251,146,60,0.9)] scale-105';
    if (lvl < 29) return 'text-red-500 font-black tracking-widest drop-shadow-[0_0_12px_rgba(239,68,68,1)] animate-pulse scale-110';
    return 'text-amber-400 font-black tracking-widest drop-shadow-[0_0_15px_rgba(245,158,11,1)] animate-bounce scale-120';
  };

  const getSwordIconUrl = (lvl: number) => {
    // Generate different fancy graphic effects for sword levels
    if (lvl === 0) return '🗡️';
    if (lvl < 5) return '⚔️';
    if (lvl < 10) return '🌟';
    if (lvl < 15) return '🔥';
    if (lvl < 20) return '🔱';
    if (lvl < 25) return '⚡';
    if (lvl < 28) return '☄️';
    return '🔮';
  };

  return (
    <div className={`min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans transition-all duration-300 ${shakeScreen ? 'animate-bounce' : ''}`}>
      {/* Dynamic confetti trigger for level 29 */}
      {showClearConfetti && (
        <div className="fixed inset-0 bg-black/80 z-50 flex flex-col items-center justify-center p-4">
          <motion.div 
            initial={{ scale: 0.5, opacity: 0 }} 
            animate={{ scale: 1, opacity: 1 }}
            className="text-center max-w-lg bg-neutral-900 border-2 border-amber-500 rounded-3xl p-8 shadow-[0_0_50px_rgba(245,158,11,0.5)]"
          >
            <Flame className="w-20 h-20 text-amber-400 mx-auto animate-bounce mb-4" />
            <span className="text-sm uppercase tracking-widest text-amber-500 font-semibold">Legendary Ascended Smith</span>
            <h1 className="text-4xl font-black mt-2 text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-amber-500 to-red-500">강화 종결자 등극!</h1>
            <p className="mt-4 text-neutral-300 leading-relaxed">
              축하드립니다! 온갖 풍파를 이겨내고 기어코 <span className="font-extrabold text-amber-400">[+29 영겁의 아포칼립스]</span>을 완성하였습니다.
              대장장이의 수많은 깡깡질이 드디어 우주최강의 신검을 빚어냈습니다.
            </p>
            <div className="mt-8 bg-neutral-950 p-4 rounded-xl border border-neutral-800 font-mono text-xs text-neutral-400 divide-y divide-neutral-900">
              <div className="flex justify-between py-1.5"><span>총 강화 시도:</span><span className="text-white">{state.statistics.totalAttempts}회</span></div>
              <div className="flex justify-between py-1.5"><span>강화 성공 횟수:</span><span className="text-green-400">{state.statistics.totalSuccesses}회</span></div>
              <div className="flex justify-between py-1.5"><span>파괴/초기화 횟수:</span><span className="text-red-400">{state.statistics.totalDestructions}회</span></div>
              <div className="flex justify-between py-1.5"><span>소모된 총 예산:</span><span className="text-amber-400 font-bold">{state.statistics.totalMoneySpent.toLocaleString()}원</span></div>
            </div>
            <div className="mt-8 flex gap-4 w-full">
              <button 
                onClick={() => {
                  setShowClearConfetti(false);
                  setState(INITIAL_STATE);
                }} 
                className="flex-1 bg-gradient-to-r from-amber-500 to-red-500 text-black hover:opacity-90 font-bold py-3 px-6 rounded-xl shadow-lg hover:shadow-amber-500/30 transition duration-300"
              >
                처음부터 다시 시도
              </button>
              <button 
                onClick={() => setShowClearConfetti(false)} 
                className="flex-1 bg-neutral-800 border border-neutral-700 font-medium hover:bg-neutral-700 py-3 px-6 rounded-xl transition duration-300"
              >
                계속 구경하기
              </button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Top Header Navigation */}
      <header className="border-b border-neutral-800 bg-neutral-900/50 backdrop-blur-md px-4 py-3 shrink-0 flex items-center justify-between sticky top-0 z-40">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-gradient-to-br from-amber-500 to-orange-600 rounded-xl max-sm:hidden">
            <Hammer className="w-6 h-6 text-neutral-950 animate-pulse" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              검 강화하기 <span className="text-xs bg-amber-500/20 text-amber-400 px-2.5 py-0.5 rounded-full font-semibold">이지 모드</span>
            </h1>
            <p className="text-xs text-neutral-400 max-sm:hidden">대장천 시뮬레이터 플래시 고전 게임의 대명사</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* File Download & Backup button */}
          <button 
            onClick={() => setShowFileModal(true)} 
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl border border-amber-500/30 bg-amber-500/10 text-amber-300 hover:text-amber-200 hover:bg-amber-500/20 transition text-xs font-semibold shadow-sm shadow-amber-500/10"
            title="프로젝트 소스코드(ZIP) 다운로드 및 세이브 데이터 백업"
          >
            <FolderDown className="w-4 h-4 text-amber-400" />
            <span className="max-sm:hidden">파일 다운로드 / 백업</span>
            <span className="sm:hidden">파일</span>
          </button>

          {/* Audio toggle button */}
          <button 
            onClick={toggleMute} 
            className="p-2.5 rounded-xl border border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-white hover:bg-neutral-900 transition"
            title={soundMuted ? '음소거 해제' : '음소거'}
          >
            {soundMuted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5 text-green-400 animate-pulse" />}
          </button>

          <button 
            onClick={handleResetGame} 
            className="p-2.5 rounded-xl border border-neutral-800 bg-neutral-950 text-neutral-400 hover:text-red-400 hover:bg-red-500/10 transition"
            title="게임 전체 초기화"
          >
            <RotateCcw className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Game Content Box */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 grid grid-cols-1 lg:grid-cols-12 gap-6 overflow-y-auto">
        
        {/* Left column (Visual forge & Action board) (Lvl < 8) */}
        <div className="lg:col-span-7 flex flex-col gap-6">
          
          {/* Main Visual Furnace representation */}
          <div className="bg-neutral-900/60 border border-neutral-800 rounded-2xl p-6 relative overflow-hidden flex flex-col items-center justify-center min-h-[290px] shadow-lg shadow-neutral-950/50">
            {/* Ambient hot coals atmosphere effect */}
            <div className="absolute inset-0 bg-gradient-to-t from-red-950/20 via-transparent to-transparent pointer-events-none" />
            <div className="absolute top-4 right-4 text-xs font-mono text-neutral-500 flex items-center gap-1.5. bg-neutral-950/60 px-2 py-1 rounded border border-neutral-800">
              <span className="w-2 h-2 rounded-full bg-red-400 animate-ping" />
              HOT TEMPERATURE
            </div>

            {/* Sword Graphic Rendering */}
            <div className="relative z-10 my-6 flex flex-col items-center">
              <AnimatePresence mode="wait">
                <motion.div 
                  key={state.currentSwordLevel}
                  initial={{ scale: 0.8, y: 10, opacity: 0 }}
                  animate={{ scale: 1, y: 0, opacity: 1, rotate: isForging ? [-5, 5, -5, 0] : 0 }}
                  transition={{ duration: 0.3 }}
                  exit={{ scale: 0.8, y: -10, opacity: 0 }}
                  className="relative flex items-center justify-center h-28 w-28 text-6xl"
                >
                  <span className="relative z-10 transition-transform hover:scale-110 cursor-pointer">
                    {getSwordIconUrl(state.currentSwordLevel)}
                  </span>
                  {/* Neon Glow under high level sword */}
                  {state.currentSwordLevel > 0 && (
                    <span className={`absolute inset-0 rounded-full filter blur-xl opacity-35 ${
                      state.currentSwordLevel < 10 ? 'bg-cyan-500' : state.currentSwordLevel < 20 ? 'bg-indigo-500' : 'bg-red-500'
                    }`} />
                  )}
                </motion.div>
              </AnimatePresence>

              {/* Ripple/Particle Success Animation Overlays */}
              <AnimatePresence>
                {showSuccessOverlay && (
                  <div key={successEffectTrigger} className="absolute inset-0 pointer-events-none z-20 flex items-center justify-center">
                    
                    {/* 1. Luxurious Aura Flash effect */}
                    <motion.div
                      initial={{ scale: 0.05, opacity: 1 }}
                      animate={{ scale: [0.1, 2.5, 3.2], opacity: [1, 0.8, 0] }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.7, ease: "easeOut" }}
                      className="absolute w-24 h-24 rounded-full bg-gradient-to-r from-yellow-400 via-rose-300 to-teal-400 filter blur-lg mix-blend-screen opacity-90"
                    />

                    {/* 2. Concentric Radiant Cosmic Ripple Rings */}
                    {[0, 1, 2, 3].map((ringIdx) => (
                      <motion.div
                        key={`ring-${ringIdx}`}
                        initial={{ scale: 0.5, opacity: 1 }}
                        animate={{ scale: 3.2 + ringIdx * 0.5, opacity: 0 }}
                        exit={{ opacity: 0 }}
                        transition={{ 
                          duration: 0.9 + ringIdx * 0.12, 
                          ease: "easeOut",
                          delay: ringIdx * 0.06
                        }}
                        className={`absolute rounded-full border-2 filter backdrop-blur-[1px] ${
                          ringIdx === 0 
                            ? 'border-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.7)]' 
                            : ringIdx === 1 
                            ? 'border-emerald-400 shadow-[0_0_20px_rgba(16,185,129,0.7)]' 
                            : ringIdx === 2
                            ? 'border-fuchsia-400 shadow-[0_0_20px_rgba(217,70,239,0.7)]'
                            : 'border-white shadow-[0_0_30px_rgba(255,255,255,0.7)] border-dashed'
                        }`}
                        style={{ width: '56px', height: '56px' }}
                      />
                    ))}

                    {/* 3. Expanded Radial Sparkle & Geometry Blast */}
                    {successParticles.map((particle) => (
                      <motion.div
                        key={particle.id}
                        initial={{ x: 0, y: 0, scale: 0.1, opacity: 1, rotate: 0 }}
                        animate={{ 
                          x: particle.xTarget, 
                          y: particle.yTarget, 
                          scale: [1, 1.4, 0], 
                          opacity: [1, 0.9, 0],
                          rotate: particle.rotateTarget
                        }}
                        exit={{ opacity: 0 }}
                        transition={{ 
                          duration: particle.duration, 
                          delay: particle.delay, 
                          ease: "easeOut" 
                        }}
                        className={`absolute flex items-center justify-center ${
                          particle.shape === 'ring' ? 'bg-transparent border-2 border-current' : particle.color
                        } ${particle.shape === 'circle' ? 'rounded-full' : ''}`}
                        style={{ 
                          width: `${particle.size}px`, 
                          height: `${particle.size}px`,
                          color: particle.color.includes('bg-white') ? '#fff' : 'inherit'
                        }}
                      >
                        {/* Custom visual geometries for extra flair */}
                        {particle.shape === 'star' && (
                          <span className="text-[14px] text-white font-black drop-shadow-[0_0_4px_rgba(255,255,255,0.8)] select-none leading-none">✦</span>
                        )}
                        {particle.shape === 'diamond' && (
                          <span className="text-[12px] text-yellow-100 font-extrabold select-none leading-none rotate-45">◆</span>
                        )}
                        {particle.shape === 'ring' && (
                          <span className="w-1.5 h-1.5 rounded-full bg-white opacity-80" />
                        )}
                      </motion.div>
                    ))}

                    {/* 4. Elegant Glassmorphic Crest Banner ("UPGRADE SUCCESS!") */}
                    <motion.div
                      initial={{ scale: 0.3, y: 30, opacity: 0, rotate: -4 }}
                      animate={{ 
                        scale: [0.3, 1.15, 1], 
                        y: [-25, -75, -80], 
                        opacity: [0, 1, 1, 0],
                        rotate: [-4, 2, 0]
                      }}
                      transition={{ 
                        duration: 1.4, 
                        times: [0, 0.25, 0.85, 1], 
                        ease: "easeOut" 
                      }}
                      className="absolute text-center select-none"
                    >
                      <div className="backdrop-blur-xl bg-neutral-900/95 border-2 border-yellow-400 shadow-[0_0_25px_rgba(245,158,11,0.5)] py-2.5 px-6 rounded-2xl flex items-center justify-center gap-2.5">
                        <motion.div
                          animate={{ rotate: 360 }}
                          transition={{ repeat: Infinity, duration: 4, ease: "linear" }}
                        >
                          <Sparkles className="w-4 h-4 text-yellow-300 fill-yellow-300" />
                        </motion.div>
                        
                        <span className="font-extrabold tracking-[0.16em] text-xs font-mono uppercase text-transparent bg-clip-text bg-gradient-to-r from-yellow-300 via-amber-200 to-yellow-400 drop-shadow-[0_2px_4px_rgba(0,0,0,0.8)]">
                          UPGRADE SUCCESS!
                        </span>

                        <motion.div
                          animate={{ scale: [1, 1.3, 1] }}
                          transition={{ repeat: Infinity, duration: 1.5, ease: "easeInOut" }}
                        >
                          <Flame className="w-4 h-4 text-orange-400 fill-orange-400 animate-pulse" />
                        </motion.div>
                      </div>
                    </motion.div>

                  </div>
                )}
              </AnimatePresence>

              <h2 className={`text-2xl font-black mt-3 ${getSwordLevelColor(state.currentSwordLevel)}`}>
                +{state.currentSwordLevel} {currentSword.name}
              </h2>
              <div className="mt-1 text-xs text-neutral-400 flex gap-2">
                <span>성공률: <b className="text-neutral-200">{(currentSword.probability * 100).toFixed(0)}%</b></span>
                <span>•</span>
                <span>판매가: <b className="text-amber-400">{currentSword.sellPrice === -1 ? '판매불가' : `${currentSword.sellPrice.toLocaleString()}원`}</b></span>
                {currentSword.isStorageRequired && (
                  <>
                    <span>•</span>
                    <span className="text-emerald-400 font-bold shrink-0">[보관필요]</span>
                  </>
                )}
              </div>
            </div>

            {/* Animation state of hammer */}
            {isForging && (
              <motion.div
                initial={{ rotate: -20, x: -10, y: -20 }}
                animate={{ rotate: 15, x: 10, y: 10 }}
                transition={{ repeat: 3, repeatType: "reverse", duration: 0.15 }}
                className="absolute z-20 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
              >
                <Hammer className="w-16 h-16 text-yellow-400 filter drop-shadow-[0_0_8px_rgba(234,179,8,0.7)]" />
              </motion.div>
            )}

            {/* Sparks Burst Effect */}
            {isForging && (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <Sparkles className="w-24 h-24 text-red-500/50 animate-ping absolute" />
                <Sparkles className="w-16 h-16 text-amber-400 animate-pulse" />
              </div>
            )}

            {/* Ground Items (Dropped Junk) */}
            <AnimatePresence>
              {state.droppedJunk && (
                <motion.div 
                  initial={{ scale: 0.2, y: 40, rotate: -40, opacity: 0 }}
                  animate={{ scale: 1, y: 0, rotate: 0, opacity: 1 }}
                  exit={{ scale: 0.2, y: -40, opacity: 0 }}
                  className="absolute bottom-4 bg-red-950/70 border border-red-500/40 rounded-xl py-2 px-4 shadow-[0_0_15px_rgba(239,68,68,0.2)] flex items-center gap-3 z-20 cursor-pointer hover:border-red-400 transition"
                  onClick={handlePickJunk}
                >
                  <Briefcase className="w-5 h-5 text-red-400 animate-bounce" />
                  <div className="text-left leading-none text-xs">
                    <p className="text-red-300 font-semibold mb-0.5">바닥에 아이템 드랍됨!</p>
                    <p className="text-neutral-300 font-bold">{JUNK_NAMES[state.droppedJunk.type]} x {state.droppedJunk.count}개</p>
                  </div>
                  <button 
                    onClick={(e) => { e.stopPropagation(); handlePickJunk(); }}
                    className="bg-red-500 hover:bg-red-400 text-black text-[10px] font-black px-2 py-1 rounded"
                  >
                    획득
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Action Tabs Menu */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl overflow-hidden flex flex-col flex-1">
            <div className="bg-neutral-950/70 p-2 border-b border-neutral-800 flex flex-wrap gap-1">
              <button
                onClick={() => setActiveTab('forge')}
                className={`flex-1 min-w-[80px] flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-xs md:text-sm font-bold transition-all ${
                  activeTab === 'forge' ? 'bg-amber-500 text-neutral-950 shadow-md' : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
                }`}
              >
                <Flame className="w-4 h-4" />
                대장간 (강화)
              </button>
              <button
                onClick={() => setActiveTab('temp_storage')}
                className={`flex-1 min-w-[80px] flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-xs md:text-sm font-bold transition-all relative ${
                  activeTab === 'temp_storage' ? 'bg-amber-500 text-neutral-950 shadow-md' : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
                }`}
              >
                <Briefcase className="w-4 h-4" />
                임시보관함
                {state.tempStorage.length > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-blue-600 px-1 text-[9px] font-black text-white">
                    {state.tempStorage.length}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('storage')}
                className={`flex-1 min-w-[80px] flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-xs md:text-sm font-bold transition-all relative ${
                  activeTab === 'storage' ? 'bg-amber-500 text-neutral-950 shadow-md' : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
                }`}
              >
                <Archive className="w-4 h-4" />
                무기/재료 창고
                {(state.storage.wangpu > 0 || state.storage.tempest > 0 || state.storage.sharp > 0) && (
                  <span className="absolute -top-1 -right-1 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-emerald-600 px-1 text-[9px] font-black text-white">
                    {state.storage.wangpu + state.storage.tempest + state.storage.sharp}
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('shop')}
                className={`flex-1 min-w-[80px] flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-xs md:text-sm font-bold transition-all ${
                  activeTab === 'shop' ? 'bg-amber-500 text-neutral-950 shadow-md' : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
                }`}
              >
                <Store className="w-4 h-4" />
                상점 (워프권)
              </button>
              <button
                onClick={() => setActiveTab('alchemy')}
                className={`flex-1 min-w-[80px] flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-xs md:text-sm font-bold transition-all relative ${
                  activeTab === 'alchemy' ? 'bg-amber-500 text-neutral-950 shadow-md' : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
                }`}
              >
                <TestTube className="w-4 h-4" />
                조합소 (연성)
                {canSynthesize && (
                  <span className="absolute top-1.5 right-1.5 flex h-2 w-2">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
                    <span className="relative inline-flex rounded-full h-2 w-2 bg-red-500"></span>
                  </span>
                )}
              </button>
              <button
                onClick={() => setActiveTab('combat')}
                className={`flex-1 min-w-[80px] flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-xs md:text-sm font-bold transition-all ${
                  activeTab === 'combat' ? 'bg-amber-500 text-neutral-950 shadow-md' : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
                }`}
              >
                <Swords className="w-4 h-4" />
                전투 (던전)
              </button>
              <button
                onClick={() => setActiveTab('stats')}
                className={`flex-1 min-w-[80px] flex items-center justify-center gap-1.5 py-2.5 px-3 rounded-lg text-xs md:text-sm font-bold transition-all ${
                  activeTab === 'stats' ? 'bg-amber-500 text-neutral-950 shadow-md' : 'text-neutral-400 hover:text-white hover:bg-neutral-900'
                }`}
              >
                <Info className="w-4 h-4" />
                성적표 (통계)
              </button>
            </div>

            <div className="p-5 flex-1 overflow-y-auto max-h-[360px]">
              {/* Tab 1: Forge */}
              {activeTab === 'forge' && (
                <div className="space-y-4">
                  {/* Protect option */}
                  <div className="bg-neutral-950/40 border border-neutral-800 p-3.5 rounded-xl flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Shield className={`w-6 h-6 ${state.protectCardEnabled ? 'text-green-400' : 'text-neutral-500'}`} />
                      <div>
                        <p className="text-sm font-bold flex items-center gap-1.5">
                          깨짐 방지권 자동 사용
                          {state.currentSwordLevel >= 26 && (
                            <span className="text-[10px] bg-red-500/20 text-red-400 px-1.5 py-0.5 rounded border border-red-500/30">하드모드 제한</span>
                          )}
                        </p>
                        <p className="text-xs text-neutral-400">
                          {currentSword.protectNeed > 0 
                            ? `현재 강화 시 실패 대처를 위해 ${currentSword.protectNeed}개가 쓰입니다.` 
                            : '현재 안전 무풍지대로 방지권 소모가 불필요합니다.'}
                        </p>
                      </div>
                    </div>
                    {state.currentSwordLevel < 26 ? (
                      <button
                        onClick={() => setState(p => ({ ...p, protectCardEnabled: !p.protectCardEnabled }))}
                        className={`text-xs font-black py-1 px-3.5 rounded-full transition ${
                          state.protectCardEnabled 
                            ? 'bg-green-500 text-black hover:bg-green-400' 
                            : 'bg-neutral-800 text-neutral-400 hover:bg-neutral-700'
                        }`}
                      >
                        {state.protectCardEnabled ? 'ON' : 'OFF'}
                      </button>
                    ) : (
                      <span className="text-xs text-red-400 font-extrabold font-mono shrink-0">사용 절대 불가</span>
                    )}
                  </div>

                  {/* Requirements List Card */}
                  <div className="bg-neutral-950/80 border border-neutral-800 p-4 rounded-xl text-xs space-y-2">
                    <h3 className="text-neutral-400 font-bold text-xs uppercase mb-1 flex items-center gap-1.5">
                      <Info className="w-3.5 h-3.5" />
                      강화 진행 세칙 조건
                    </h3>
                    
                    {/* Money cost */}
                    <div className="flex justify-between items-center py-1 border-b border-neutral-900 last:border-b-0">
                      <span className="text-neutral-400">요구 소모 잔액:</span>
                      <span className={`${state.money >= currentSword.cost ? 'text-green-400' : 'text-red-500'} font-bold font-mono`}>
                        {currentSword.cost === 0 ? '무료' : `${currentSword.cost.toLocaleString()}원`} (보유: {state.money.toLocaleString()}원)
                      </span>
                    </div>

                    {/* Protect Card required */}
                    {currentSword.protectNeed > 0 && (
                      <div className="flex justify-between items-center py-1 border-b border-neutral-900 last:border-b-0">
                        <span className="text-neutral-400">정밀 차단 방지권 수량:</span>
                        <span className={`${state.protectCards >= currentSword.protectNeed ? 'text-green-400' : 'text-amber-500'} font-bold font-mono`}>
                          {currentSword.protectNeed}개 대기 (보유: {state.protectCards}개)
                        </span>
                      </div>
                    )}

                    {/* Material Item check */}
                    {currentSword.material && (
                      <div className="flex justify-between items-center py-1 border-b border-neutral-900 last:border-b-0 bg-amber-500/5 p-2 rounded border border-amber-500/10">
                        <span className="text-amber-400 font-bold flex items-center gap-1">📍 강화 필수 제물 무기/잡템:</span>
                        <span className="font-bold flex items-center gap-1">
                          {currentSword.material.type === 'weapon' ? (
                            <>
                              {currentSword.material.key === 'wangpu' ? '전뇌 카두케우스 (+19)' : currentSword.material.key === 'tempest' ? '템페스트 가브리엘 (+21)' : '광속의 크로노스 (+22)'}
                              {' '}<span className={state.storage[currentSword.material.key as keyof typeof state.storage] >= currentSword.material.count ? 'text-green-400' : 'text-red-500'}>
                                {currentSword.material.count}자루 (보유: {state.storage[currentSword.material.key as keyof typeof state.storage]})
                              </span>
                            </>
                          ) : (
                            <>
                              {JUNK_NAMES[currentSword.material.key as keyof JSTState]}
                              {' '}<span className={state.junks[currentSword.material.key as keyof JSTState] >= currentSword.material.count ? 'text-green-400' : 'text-red-500'}>
                                {currentSword.material.count}개 (보유: {state.junks[currentSword.material.key as keyof JSTState]})
                              </span>
                            </>
                          )}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Actions (Enhance / Sell / Storage / Pick Drop) */}
                  <div className="flex flex-wrap gap-2.5">
                    {/* Enhance Button */}
                    <button
                      onClick={handleEnhance}
                      disabled={isForging || isCombating || (state.currentSwordLevel >= 29)}
                      className={`flex-1 min-w-[130px] font-black tracking-wider py-4 px-6 rounded-xl text-neutral-950 flex items-center justify-center gap-2 transition duration-300 transform active:scale-95 ${
                        isForging || isCombating
                          ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                          : state.currentSwordLevel >= 29
                          ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                          : 'bg-gradient-to-r from-amber-400 via-amber-500 to-orange-500 hover:from-amber-300 hover:to-orange-400 font-black shadow-lg shadow-amber-500/25'
                      }`}
                    >
                      <Hammer className={`w-5 h-5 ${isForging ? 'animate-bounce' : ''}`} />
                      {isForging ? '강화 연동 중...' : isCombating ? '전투 중 시도 불가' : '검 강화하기 (Space)'}
                    </button>

                    {/* Consecutive Enhance Button */}
                    <button
                      onClick={handleConsecutiveEnhance}
                      disabled={isForging || isCombating || (state.currentSwordLevel >= 29)}
                      className={`flex-1 min-w-[130px] font-black tracking-wider py-4 px-6 rounded-xl text-neutral-950 flex items-center justify-center gap-2 transition duration-300 transform active:scale-95 ${
                        isForging || isCombating
                          ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                          : state.currentSwordLevel >= 29
                          ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                          : 'bg-gradient-to-r from-fuchsia-400 via-violet-500 to-indigo-500 hover:from-fuchsia-300 hover:to-indigo-400 text-white font-black shadow-lg shadow-fuchsia-500/25 border border-fuchsia-300/20'
                      }`}
                    >
                      <Sparkles className={`w-5 h-5 ${isConsecutive ? 'animate-spin' : ''}`} />
                      {isConsecutive ? '연속 강화 중...' : isForging ? '대기 중...' : isCombating ? '전투 중 불가' : '연속 5회 강화 (C)'}
                    </button>

                    {/* Sell Button */}
                    <button
                      onClick={handleSell}
                      disabled={isForging || isCombating || currentSword.sellPrice === -1}
                      className={`font-bold py-4 px-5 rounded-xl border flex items-center justify-center gap-1.5 transition active:scale-95 ${
                        currentSword.sellPrice === -1 || isCombating
                          ? 'border-neutral-800 bg-neutral-950 text-neutral-600 cursor-not-allowed' 
                          : 'border-yellow-500/30 bg-yellow-500/5 text-yellow-400 hover:bg-yellow-500/15'
                      }`}
                    >
                      <Coins className="w-4 h-4" />
                      판매 ({currentSword.sellPrice === -1 ? '-' : currentSword.sellPrice.toLocaleString()})
                    </button>

                    {/* Store Button */}
                    {currentSword.isStorageRequired && (
                      <button
                        onClick={handleStoreSword}
                        disabled={isForging || isCombating}
                        className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 text-neutral-950 font-black tracking-widest py-3 px-6 rounded-xl hover:opacity-90 transform active:scale-95 transition flex items-center justify-center gap-1.5"
                      >
                        <Briefcase className="w-4 h-4" />
                        보관함으로 무기 보관하기
                      </button>
                    )}

                    {/* Temp Storage Slots (Up to 5) */}
                    <div className="w-full bg-neutral-900/40 border border-neutral-800 rounded-xl p-3.5 mt-2 space-y-3.5">
                      <div className="flex justify-between items-center">
                        <span className="text-xs font-black text-neutral-300 flex items-center gap-1.5">
                          <Briefcase className="w-4 h-4 text-blue-400" />
                          임시 보관함 Slots ({state.tempStorage.length}/5)
                        </span>
                        
                        {/* Store Button */}
                        <button
                          onClick={handleTempStore}
                          disabled={isForging || isCombating || state.tempStorage.length >= 5 || state.currentSwordLevel === 0}
                          className={`font-black tracking-wider py-1.5 px-3 rounded-lg text-xs transition duration-200 active:scale-95 flex items-center gap-1.5 ${
                            state.tempStorage.length >= 5 || state.currentSwordLevel === 0 || isCombating
                              ? 'bg-neutral-800/50 text-neutral-600 border border-neutral-800/30 cursor-not-allowed'
                              : 'bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/30'
                          }`}
                          title={state.currentSwordLevel === 0 ? "장착 중인 검이 있어야 보관할 수 있습니다." : "임시 보관함이 가득 찼습니다."}
                        >
                          <Plus className="w-3.5 h-3.5" />
                          현재 검 보관
                        </button>
                      </div>

                      {/* Slots Layout */}
                      <div className="grid grid-cols-1 gap-2">
                        {[0, 1, 2, 3, 4].map((idx) => {
                          const item = state.tempStorage[idx];
                          return (
                            <div 
                              key={idx} 
                              className={`flex items-center justify-between p-2.5 rounded-lg border text-xs transition duration-200 ${
                                item 
                                  ? 'border-neutral-800 bg-neutral-950/80 hover:border-neutral-700' 
                                  : 'border-dashed border-neutral-800/60 bg-neutral-950/20 opacity-40'
                              }`}
                            >
                              <div className="flex items-center gap-2.5">
                                <span className="font-mono text-neutral-500 font-bold bg-neutral-900 px-1.5 py-0.5 rounded">SLOT {idx + 1}</span>
                                {item ? (
                                  <span className={`font-bold ${getSwordLevelColor(item.level)}`}>
                                    +{item.level} {item.name}
                                  </span>
                                ) : (
                                  <span className="text-neutral-600 italic">비어있음</span>
                                )}
                              </div>

                              {item && (
                                <div className="flex items-center gap-1.5">
                                  {/* Retrieve / Swap Button */}
                                  <button
                                    onClick={() => handleTempRetrieve(idx)}
                                    disabled={isForging || isCombating}
                                    className={`py-1 px-3 rounded font-black tracking-wider transition active:scale-95 text-[11px] ${
                                      isForging || isCombating
                                        ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                                        : state.currentSwordLevel !== 0
                                        ? 'bg-blue-600 hover:bg-blue-500 text-white'
                                        : 'bg-emerald-500 hover:bg-emerald-400 text-neutral-950'
                                    }`}
                                    title={state.currentSwordLevel !== 0 ? "현재 장착 중인 검과 보관함 슬롯의 검을 맞교환합니다." : "보관함 슬롯의 무기를 꺼내어 다시 장착합니다."}
                                  >
                                    {state.currentSwordLevel !== 0 ? '교환' : '꺼내기'}
                                  </button>
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab: Temp Storage */}
              {activeTab === 'temp_storage' && (
                <div className="space-y-4">
                  {/* Summary Header */}
                  <div className="bg-blue-500/10 border border-blue-500/20 p-3.5 rounded-xl flex items-center gap-3">
                    <Briefcase className="w-6 h-6 text-blue-400 shrink-0 animate-pulse" />
                    <div>
                      <p className="text-xs font-bold text-blue-300">전투 및 예비용 임시보관함</p>
                      <p className="text-[11px] text-neutral-400 leading-relaxed mt-0.5">
                        대장간에서 강화 중인 무기를 안전하게 보존하고 다른 무기를 수련할 수 있도록 최대 5개의 무기를 임시 보관할 수 있습니다. 보관된 무기는 전투 출격 시 선택해서 무사히 비파괴 출전이 가능합니다.
                      </p>
                    </div>
                  </div>

                  {/* Temp Storage Slots */}
                  <div className="bg-neutral-950/40 border border-neutral-800 p-4 rounded-xl">
                    <div className="flex justify-between items-center mb-3">
                      <span className="text-xs font-black text-neutral-300 flex items-center gap-1.5">
                        <Briefcase className="w-4 h-4 text-blue-400" />
                        임시 보관 슬롯 ({state.tempStorage.length}/5)
                      </span>
                      <button
                        onClick={handleTempStore}
                        disabled={isForging || isCombating || state.tempStorage.length >= 5 || state.currentSwordLevel === 0}
                        className={`font-black tracking-wider py-1.5 px-3 rounded-lg text-xs transition duration-200 active:scale-95 flex items-center gap-1.5 ${
                          state.tempStorage.length >= 5 || state.currentSwordLevel === 0 || isCombating
                            ? 'bg-neutral-800/50 text-neutral-600 border border-neutral-800/30 cursor-not-allowed'
                            : 'bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/30'
                        }`}
                      >
                        <Plus className="w-3.5 h-3.5" />
                        현재 무기 보관
                      </button>
                    </div>

                    <div className="grid grid-cols-1 gap-2">
                      {[0, 1, 2, 3, 4].map((idx) => {
                        const item = state.tempStorage[idx];
                        return (
                          <div 
                            key={idx} 
                            className={`flex items-center justify-between p-2.5 rounded-lg border text-xs transition duration-200 ${
                              item 
                                ? 'border-neutral-800 bg-neutral-950/80 hover:border-neutral-700' 
                                : 'border-dashed border-neutral-800/60 bg-neutral-950/20 opacity-40'
                            }`}
                          >
                            <div className="flex items-center gap-2.5">
                              <span className="font-mono text-neutral-500 font-bold bg-neutral-900 px-1.5 py-0.5 rounded">SLOT {idx + 1}</span>
                              {item ? (
                                <span className={`font-bold ${getSwordLevelColor(item.level)}`}>
                                  +{item.level} {item.name}
                                </span>
                              ) : (
                                <span className="text-neutral-600 italic">비어있음</span>
                              )}
                            </div>

                            {item && (
                              <div className="flex items-center gap-1.5">
                                <button
                                  onClick={() => handleTempRetrieve(idx)}
                                  disabled={isForging || isCombating}
                                  className="bg-neutral-800 hover:bg-neutral-700 text-neutral-300 hover:text-white font-bold py-1 px-3 rounded text-[11px] transition duration-150 active:scale-95 disabled:opacity-50"
                                >
                                  {state.currentSwordLevel !== 0 ? '교환' : '꺼내기'}
                                </button>
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}

              {/* Tab: Storage */}
              {activeTab === 'storage' && (
                <div className="space-y-4">
                  {/* Summary Header */}
                  <div className="bg-emerald-500/10 border border-emerald-500/20 p-3.5 rounded-xl flex items-center gap-3">
                    <Archive className="w-6 h-6 text-emerald-400 shrink-0 animate-pulse" />
                    <div>
                      <p className="text-xs font-bold text-emerald-300">중앙 메인 무기 및 재료 창고</p>
                      <p className="text-[11px] text-neutral-400 leading-relaxed mt-0.5">
                        최상위 연성소 조합용 특수 제물 장비들과 모험/전투를 통해 수집한 각종 고유 희귀 강화 재료들을 보관하는 중심 창고시스템입니다.
                      </p>
                    </div>
                  </div>

                  {/* Active material weapon storage shortcut */}
                  {currentSword.isStorageRequired && (
                    <div className="bg-emerald-500/5 border border-emerald-500/20 p-3.5 rounded-xl flex items-center justify-between">
                      <div>
                        <p className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider">장착 중인 제물 무기 감지됨</p>
                        <p className={`text-xs font-black mt-0.5 ${getSwordLevelColor(state.currentSwordLevel)}`}>
                          +{state.currentSwordLevel} {currentSword.name}
                        </p>
                      </div>
                      <button
                        onClick={handleStoreSword}
                        disabled={isForging || isCombating}
                        className="bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-black px-3.5 py-2 rounded-lg text-xs transition duration-200 active:scale-95 flex items-center gap-1.5 shadow-md shadow-emerald-500/10"
                      >
                        <Archive className="w-4 h-4" />
                        창고로 즉시 보관
                      </button>
                    </div>
                  )}

                  {/* Main Material Weapons Storage */}
                  <div className="bg-neutral-950/40 border border-neutral-800 p-4 rounded-xl space-y-3">
                    <span className="text-xs font-black text-neutral-300 flex items-center gap-1.5">
                      <Archive className="w-4 h-4 text-emerald-400" />
                      제물 무기 창고 (조합/강화 전용 보관검)
                    </span>

                    <div className="grid grid-cols-1 gap-2 text-xs">
                      {/* Wangpu (+19) */}
                      <div className="bg-neutral-950/60 p-3 rounded-xl border border-neutral-800 flex justify-between items-center">
                        <div>
                          <p className={`font-bold ${getSwordLevelColor(19)} flex items-center gap-1`}>
                            전뇌 카두케우스 (+19)
                          </p>
                          <p className="text-neutral-400 mt-0.5">보유 수량: <b className="text-emerald-400">{state.storage.wangpu}</b>자루</p>
                        </div>
                        <button
                          onClick={() => handleWithdrawFromStorage('wangpu')}
                          disabled={state.storage.wangpu <= 0 || isForging || isCombating}
                          className={`py-1.5 px-3 rounded-lg font-black text-xs transition duration-200 active:scale-95 ${
                            state.storage.wangpu <= 0 || isForging || isCombating
                              ? 'bg-neutral-800/40 text-neutral-600 cursor-not-allowed'
                              : 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          }`}
                        >
                          📦 꺼내기
                        </button>
                      </div>

                      {/* Tempest (+21) */}
                      <div className="bg-neutral-950/60 p-3 rounded-xl border border-neutral-800 flex justify-between items-center">
                        <div>
                          <p className={`font-bold ${getSwordLevelColor(21)} flex items-center gap-1`}>
                            템페스트 가브리엘 (+21)
                          </p>
                          <p className="text-neutral-400 mt-0.5">보유 수량: <b className="text-emerald-400">{state.storage.tempest}</b>자루</p>
                        </div>
                        <button
                          onClick={() => handleWithdrawFromStorage('tempest')}
                          disabled={state.storage.tempest <= 0 || isForging || isCombating}
                          className={`py-1.5 px-3 rounded-lg font-black text-xs transition duration-200 active:scale-95 ${
                            state.storage.tempest <= 0 || isForging || isCombating
                              ? 'bg-neutral-800/40 text-neutral-600 cursor-not-allowed'
                              : 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          }`}
                        >
                          📦 꺼내기
                        </button>
                      </div>

                      {/* Sharp (+22) */}
                      <div className="bg-neutral-950/60 p-3 rounded-xl border border-neutral-800 flex justify-between items-center">
                        <div>
                          <p className={`font-bold ${getSwordLevelColor(22)} flex items-center gap-1`}>
                            광속의 크로노스 (+22)
                          </p>
                          <p className="text-neutral-400 mt-0.5">보유 수량: <b className="text-emerald-400">{state.storage.sharp}</b>자루</p>
                        </div>
                        <button
                          onClick={() => handleWithdrawFromStorage('sharp')}
                          disabled={state.storage.sharp <= 0 || isForging || isCombating}
                          className={`py-1.5 px-3 rounded-lg font-black text-xs transition duration-200 active:scale-95 ${
                            state.storage.sharp <= 0 || isForging || isCombating
                              ? 'bg-neutral-800/40 text-neutral-600 cursor-not-allowed'
                              : 'bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                          }`}
                        >
                          📦 꺼내기
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Materials & Items Inventory */}
                  <div className="bg-neutral-950/40 border border-neutral-800 p-4 rounded-xl">
                    <span className="text-xs font-black text-neutral-300 flex items-center gap-1.5 mb-3">
                      <Briefcase className="w-4 h-4 text-amber-400" />
                      수집한 희귀 강화 재료 인벤토리
                    </span>

                    <div className="grid grid-cols-2 gap-2 text-[11px]">
                      <div className="bg-neutral-950/50 p-2 rounded-lg border border-neutral-900 flex justify-between items-center">
                        <span className="text-neutral-400">🌊 심해 철광</span>
                        <span className="font-bold text-neutral-200">{state.junks.ironPiece}개</span>
                      </div>
                      <div className="bg-neutral-950/50 p-2 rounded-lg border border-neutral-900 flex justify-between items-center">
                        <span className="text-neutral-400">🦴 바소렉 야수뼈</span>
                        <span className="font-bold text-neutral-200">{state.junks.tauBone}개</span>
                      </div>
                      <div className="bg-neutral-950/50 p-2 rounded-lg border border-neutral-900 flex justify-between items-center">
                        <span className="text-neutral-400">✨ 에테르 성수</span>
                        <span className="font-bold text-amber-400">{state.junks.fluorescence}개</span>
                      </div>
                      <div className="bg-neutral-950/50 p-2 rounded-lg border border-neutral-900 flex justify-between items-center">
                        <span className="text-neutral-400">🐉 가리온 비늘</span>
                        <span className="font-bold text-neutral-200">{state.junks.swissIron}개</span>
                      </div>
                      <div className="bg-neutral-950/50 p-2 rounded-lg border border-neutral-900 flex justify-between items-center">
                        <span className="text-neutral-400">🔥 불안정한 손잡이</span>
                        <span className="font-bold text-amber-400">{state.junks.fieryHandle}개</span>
                      </div>
                      <div className="bg-neutral-950/50 p-2 rounded-lg border border-neutral-900 flex justify-between items-center">
                        <span className="text-neutral-400">👻 나락의 원혼</span>
                        <span className="font-bold text-neutral-200">{state.junks.evilSoul}개</span>
                      </div>
                      <div className="bg-neutral-950/50 p-2 rounded-lg border border-neutral-900 flex justify-between items-center">
                        <span className="text-neutral-400">☄️ 무한 마력 가루</span>
                        <span className="font-bold text-neutral-200">{state.junks.axePowder}개</span>
                      </div>
                      <div className="bg-neutral-950/50 p-2 rounded-lg border border-neutral-900 flex justify-between items-center">
                        <span className="text-neutral-400">🔮 보이드 암흑 물질</span>
                        <span className="font-bold text-neutral-200">{state.junks.invisibleMaterial}개</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 2: Shop */}
              {activeTab === 'shop' && (
                <div className="space-y-4">
                  <div className="bg-amber-500/10 border border-amber-500/20 p-3.5 rounded-xl flex items-center gap-3">
                    <Store className="w-6 h-6 text-amber-500 shrink-0" />
                    <p className="text-xs text-neutral-300 leading-relaxed">
                      워프권을 요긴하게 장만해, 복잡해지는 수많은 초기 단계를 단숨에 주파하십시오!
                    </p>
                  </div>

                  {/* Shop Items Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs">
                    {/* Protect 1 */}
                    <div className="bg-neutral-950/60 p-3 rounded-xl border border-neutral-800 flex justify-between items-center">
                      <div>
                        <p className="font-bold text-white">깨짐 방지권 1개</p>
                        <p className="text-neutral-400 font-mono">1,000,000원</p>
                      </div>
                      <button 
                        onClick={() => handleBuyShop('protect_1', 1000000)}
                        className="bg-amber-500 text-black font-extrabold px-3 py-1.5 rounded hover:bg-amber-400 transition"
                      >
                        구매
                      </button>
                    </div>

                    {/* Protect 3 */}
                    <div className="bg-neutral-950/60 p-3 rounded-xl border border-neutral-800 flex justify-between items-center">
                      <div>
                        <p className="font-bold text-green-400 flex items-center gap-1">깨짐 방지권 3개 <span className="text-[10px] bg-green-500/10 text-green-400 px-1 rounded">할인</span></p>
                        <p className="text-neutral-400 font-mono">2,500,000원</p>
                      </div>
                      <button 
                        onClick={() => handleBuyShop('protect_3', 2500000)}
                        className="bg-amber-500 text-black font-extrabold px-3 py-1.5 rounded hover:bg-amber-400 transition"
                      >
                        구매
                      </button>
                    </div>

                    {/* Warp +9 */}
                    <div className="bg-neutral-950/60 p-3 rounded-xl border border-neutral-800 flex justify-between items-center">
                      <div>
                        <p className="font-bold text-white flex items-center gap-1">🎫 +9 대야수 미노타우로스의 격노검 워프권</p>
                        <p className="text-neutral-400 font-mono">1,000,000원</p>
                        {warpTickets[9] > 0 && <p className="text-cyan-400 font-semibold">현재 보유: {warpTickets[9]}개</p>}
                      </div>
                      <div className="flex flex-col gap-1.5">
                        <button 
                          onClick={() => handleBuyShop('warp_9', 1000000)}
                          className="bg-amber-500 text-black font-extrabold px-3 py-1.5 rounded hover:bg-amber-400 transition text-center"
                        >
                          구매
                        </button>
                        {warpTickets[9] > 0 && (
                          <button 
                            onClick={() => handleUseWarp(9)}
                            className="bg-cyan-500 text-black font-black px-2 py-1 rounded text-[10px] animate-pulse"
                          >
                            사용하기
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Warp +13 */}
                    <div className="bg-neutral-950/60 p-3 rounded-xl border border-neutral-800 flex justify-between items-center">
                      <div>
                        <p className="font-bold text-white flex items-center gap-1">🎫 +13 연옥의 맹화 헬하임 소울 이터 워프권</p>
                        <p className="text-neutral-400 font-mono">7,000,000원</p>
                        {warpTickets[13] > 0 && <p className="text-cyan-400 font-semibold">현재 보유: {warpTickets[13]}개</p>}
                      </div>
                      <div className="flex flex-col gap-1.5">
                        <button 
                          onClick={() => handleBuyShop('warp_13', 7000000)}
                          className="bg-amber-500 text-black font-extrabold px-3 py-1.5 rounded hover:bg-amber-400 transition text-center"
                        >
                          구매
                        </button>
                        {warpTickets[13] > 0 && (
                          <button 
                            onClick={() => handleUseWarp(13)}
                            className="bg-cyan-500 text-black font-black px-2 py-1 rounded text-[10px] animate-pulse"
                          >
                            사용하기
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Warp +14 */}
                    <div className="bg-neutral-950/60 p-3 rounded-xl border border-neutral-800 flex justify-between items-center">
                      <div>
                        <p className="font-bold text-white flex items-center gap-1">🎫 +14 아포피스 시미터 워프권</p>
                        <p className="text-neutral-400 font-mono">10,000,000원</p>
                        {warpTickets[14] > 0 && <p className="text-cyan-400 font-semibold">현재 보유: {warpTickets[14]}개</p>}
                      </div>
                      <div className="flex flex-col gap-1.5">
                        <button 
                          onClick={() => handleBuyShop('warp_14', 10000000)}
                          className="bg-amber-500 text-black font-extrabold px-3 py-1.5 rounded hover:bg-amber-400 transition text-center"
                        >
                          구매
                        </button>
                        {warpTickets[14] > 0 && (
                          <button 
                            onClick={() => handleUseWarp(14)}
                            className="bg-cyan-500 text-black font-black px-2 py-1 rounded text-[10px] animate-pulse"
                          >
                            사용하기
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Warp +15 */}
                    <div className="bg-neutral-950/60 p-3 rounded-xl border border-neutral-800 flex justify-between items-center">
                      <div>
                        <p className="font-bold text-white flex items-center gap-1">🎫 +15 데몬 헤일 배틀 엑스 워프권</p>
                        <p className="text-neutral-400 font-mono">15,000,000원</p>
                        {warpTickets[15] > 0 && <p className="text-cyan-400 font-semibold">현재 보유: {warpTickets[15]}개</p>}
                      </div>
                      <div className="flex flex-col gap-1.5">
                        <button 
                          onClick={() => handleBuyShop('warp_15', 15000000)}
                          className="bg-amber-500 text-black font-extrabold px-3 py-1.5 rounded hover:bg-amber-400 transition text-center"
                        >
                          구매
                        </button>
                        {warpTickets[15] > 0 && (
                          <button 
                            onClick={() => handleUseWarp(15)}
                            className="bg-cyan-500 text-black font-black px-2 py-1 rounded text-[10px] animate-pulse"
                          >
                            사용하기
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab 3: Alchemy */}
              {activeTab === 'alchemy' && (
                <div className="space-y-4">
                  <div className="bg-emerald-500/10 border border-emerald-500/20 p-3 rounded-xl flex items-center gap-3">
                    <TestTube className="w-5 h-5 text-emerald-400 shrink-0" />
                    <p className="text-xs text-neutral-300 leading-normal">
                      파괴 과정에서 모아낸 수집품(잡템)들을 소모하여 희귀 방지권을 확보하거나 강력한 마무덤을 연성하세요!
                    </p>
                  </div>

                  {/* Recipes List */}
                  <div className="space-y-2 text-xs">
                    {/* Recipe 1 */}
                    <div className="bg-neutral-950/50 p-2.5 rounded-lg border border-neutral-800 flex justify-between items-center">
                      <div>
                        <p className="font-bold">차가운 심해의 철광 석판 5개 ➡️ 깨짐 방지권 1개</p>
                        <p className="text-neutral-500">심해 철광 보유: {state.junks.ironPiece} / 5개</p>
                      </div>
                      <button 
                        onClick={() => handleCombine(1)}
                        className={`font-black py-1 px-3 rounded text-[10px] active:scale-95 transition ${
                          state.junks.ironPiece >= 5 ? 'bg-emerald-500 text-black hover:bg-emerald-400' : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                        }`}
                      >
                        연성
                      </button>
                    </div>

                    {/* Recipe 2 */}
                    <div className="bg-neutral-950/50 p-2.5 rounded-lg border border-neutral-800 flex justify-between items-center">
                      <div>
                        <p className="font-bold">고대 파괴수 바소렉의 상아 뼈 화석 3개 ➡️ 깨짐 방지권 1개</p>
                        <p className="text-neutral-500">바소렉 야수뼈 보유: {state.junks.tauBone} / 3개</p>
                      </div>
                      <button 
                        onClick={() => handleCombine(2)}
                        className={`font-black py-1 px-3 rounded text-[10px] active:scale-95 transition ${
                          state.junks.tauBone >= 3 ? 'bg-emerald-500 text-black hover:bg-emerald-400' : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                        }`}
                      >
                        연성
                      </button>
                    </div>

                    {/* Recipe 3 */}
                    <div className="bg-neutral-950/50 p-2.5 rounded-lg border border-neutral-800 flex justify-between items-center bg-amber-500/5">
                      <div>
                        <p className="font-bold text-amber-400">✨ 성령의 푸른빛 에테르 성수 2개 ➡️ +13강 연옥의 맹화 헬하임 소울 이터</p>
                        <p className="text-neutral-500">에테르 성수 보유: {state.junks.fluorescence} / 2개</p>
                      </div>
                      <button 
                        onClick={() => handleCombine(3)}
                        className={`font-black py-1 px-3 rounded text-[10px] active:scale-95 transition ${
                          state.junks.fluorescence >= 2 ? 'bg-amber-400 text-black hover:bg-amber-300' : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                        }`}
                      >
                        연성
                      </button>
                    </div>

                    {/* Recipe 4 */}
                    <div className="bg-neutral-950/50 p-2.5 rounded-lg border border-neutral-800 flex justify-between items-center">
                      <div>
                        <p className="font-bold">은빛 용황 가리온의 비늘 파편 3개 ➡️ 깨짐 방지권 2개</p>
                        <p className="text-neutral-500">가리온 비늘 보유: {state.junks.swissIron} / 3개</p>
                      </div>
                      <button 
                        onClick={() => handleCombine(4)}
                        className={`font-black py-1 px-3 rounded text-[10px] active:scale-95 transition ${
                          state.junks.swissIron >= 3 ? 'bg-emerald-500 text-black hover:bg-emerald-400' : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                        }`}
                      >
                        연성
                      </button>
                    </div>

                    {/* Recipe 5 */}
                    <div className="bg-neutral-950/50 p-2.5 rounded-lg border border-neutral-800 flex justify-between items-center bg-amber-500/5">
                      <div>
                        <p className="font-bold text-amber-400">✨ 지옥불 불태우는 불안정한 손잡이 2개 ➡️ +16강 무형의 차원 붕괴 보이드 팬텀</p>
                        <p className="text-neutral-500">불안정한 손잡이 보유: {state.junks.fieryHandle} / 2개</p>
                      </div>
                      <button 
                        onClick={() => handleCombine(5)}
                        className={`font-black py-1 px-3 rounded text-[10px] active:scale-95 transition ${
                          state.junks.fieryHandle >= 2 ? 'bg-amber-400 text-black hover:bg-amber-300' : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                        }`}
                      >
                        연성
                      </button>
                    </div>

                    {/* Recipe 6 */}
                    <div className="bg-neutral-950/50 p-2.5 rounded-lg border border-neutral-800 flex justify-between items-center">
                      <div>
                        <p className="font-bold">망각의 나락에서 울부짖는 원혼 4개 ➡️ 깨짐 방지권 4개</p>
                        <p className="text-neutral-500">원혼 보유: {state.junks.evilSoul} / 4개</p>
                      </div>
                      <button 
                        onClick={() => handleCombine(6)}
                        className={`font-black py-1 px-3 rounded text-[10px] active:scale-95 transition ${
                          state.junks.evilSoul >= 4 ? 'bg-emerald-500 text-black hover:bg-emerald-400' : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                        }`}
                      >
                        연성
                      </button>
                    </div>

                    {/* Recipe 7 */}
                    <div className="bg-neutral-950/50 p-2.5 rounded-lg border border-neutral-800 flex justify-between items-center bg-amber-500/5">
                      <div>
                        <p className="font-bold text-amber-400">✨ 망각의 나락에서 울부짖는 원혼 6개 ➡️ +19강 전뇌 카두케우스</p>
                        <p className="text-neutral-500">원혼 보유: {state.junks.evilSoul} / 6개</p>
                      </div>
                      <button 
                        onClick={() => handleCombine(7)}
                        className={`font-black py-1 px-3 rounded text-[10px] active:scale-95 transition ${
                          state.junks.evilSoul >= 6 ? 'bg-amber-400 text-black hover:bg-amber-300' : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                        }`}
                      >
                        연성
                      </button>
                    </div>

                    {/* Recipe 8 */}
                    <div className="bg-neutral-950/50 p-2.5 rounded-lg border border-neutral-800 flex justify-between items-center">
                      <div>
                        <p className="font-bold">차원을 참수하는 무한 마력 가루 6개 ➡️ 깨짐 방지권 10개</p>
                        <p className="text-neutral-500">마력 가루 보유: {state.junks.axePowder} / 6개</p>
                      </div>
                      <button 
                        onClick={() => handleCombine(8)}
                        className={`font-black py-1 px-3 rounded text-[10px] active:scale-95 transition ${
                          state.junks.axePowder >= 6 ? 'bg-emerald-500 text-black hover:bg-emerald-400' : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                        }`}
                      >
                        연성
                      </button>
                    </div>

                    {/* Recipe 9 */}
                    <div className="bg-neutral-950/50 p-2.5 rounded-lg border border-neutral-800 flex justify-between items-center">
                      <div>
                        <p className="font-bold">시공간 왜곡의 보이드 암흑 물질 3개 ➡️ 깨짐 방지권 9개</p>
                        <p className="text-neutral-500">암흑 물질 보유: {state.junks.invisibleMaterial} / 3개</p>
                      </div>
                      <button 
                        onClick={() => handleCombine(9)}
                        className={`font-black py-1 px-3 rounded text-[10px] active:scale-95 transition ${
                          state.junks.invisibleMaterial >= 3 ? 'bg-emerald-500 text-black hover:bg-emerald-400' : 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                        }`}
                      >
                        연성
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* Tab: Combat */}
              {activeTab === 'combat' && (
                <div className="space-y-4">
                  <div className="bg-gradient-to-r from-red-950/40 to-neutral-900/40 border border-red-500/10 p-3.5 rounded-xl">
                    <p className="text-xs text-neutral-300 leading-relaxed font-semibold flex items-center gap-2">
                      <Swords className="w-5 h-5 text-red-500 shrink-0 animate-pulse" />
                      전투 시스템: 임시 보관함 무기를 활용해 고난도의 던전 보스들을 격파하고 대량의 보상을 획득하십시오! <b>(검 파괴 없음)</b>
                    </p>
                  </div>

                  {/* Sword Selector */}
                  <div className="bg-neutral-950/80 p-3.5 border border-neutral-800 rounded-xl space-y-2.5">
                    <p className="text-[11px] font-bold text-neutral-400 font-mono tracking-wider">🎯 출격할 무기 선택 (임시 보관함 슬롯)</p>
                    {state.tempStorage.length === 0 ? (
                      <p className="text-xs text-neutral-500 italic">임시 보관함에 보관된 무기가 없습니다. 대장간 탭에서 무기를 임시 보존 처리 후 대장간 강화용 무기 비우기를 진행하여 여기에 보관하십시오.</p>
                    ) : (
                      <div className="grid grid-cols-1 gap-2">
                        {state.tempStorage.map((item, sIdx) => (
                          <div 
                            key={sIdx} 
                            className="flex items-center justify-between bg-neutral-900/60 p-2.5 rounded-lg border border-neutral-800 text-xs"
                          >
                            <span className="font-bold text-neutral-300">
                              Slot {sIdx + 1}: <span className={getSwordLevelColor(item.level)}>+{item.level} {item.name}</span>
                            </span>
                            <span className="text-[10px] text-zinc-500">진입 규격: +{item.level}강 등급</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Stages List */}
                  <div className="space-y-3">
                    {STAGES.map((stg) => {
                      const bestUsableSword = [...state.tempStorage]
                        .filter(itm => itm.level >= stg.minLevel)
                        .sort((a, b) => b.level - a.level)[0];

                      const canEnter = !!bestUsableSword;
                      const winChance = bestUsableSword ? stg.getWinRate(bestUsableSword.level) : 0;

                      return (
                        <div 
                          key={stg.index}
                          className={`bg-neutral-950/60 border rounded-xl p-3.5 flex flex-col justify-between gap-3.5 transition duration-200 ${
                            canEnter 
                              ? 'border-neutral-800 hover:border-red-500/20' 
                              : 'border-dashed border-neutral-800/60 opacity-60'
                          }`}
                        >
                          <div className="flex justify-between items-start">
                            <div>
                              <div className="flex items-center gap-2">
                                <span className="bg-red-500/10 border border-red-500/20 text-red-400 font-black px-1.5 py-0.5 rounded text-[10px] uppercase font-mono">Stage {stg.index}</span>
                                <h3 className="font-black text-rose-300 text-sm">{stg.name}</h3>
                              </div>
                              <p className="text-[11px] text-zinc-400 mt-1">
                                👾 등장: {stg.monster} ➡️ <b className="text-zinc-300">보스 {stg.boss}</b>
                              </p>
                              <p className="text-[10px] text-zinc-500 mt-0.5">
                                진입 규격: 임시 보관함에 <b className="text-red-400">+{stg.minLevel}강</b> 이상 검 보유 필요
                              </p>
                            </div>
                            <div className="text-right font-mono">
                              <p className="text-[10px] text-zinc-500">클리어 보상</p>
                              <p className="text-amber-400 text-sm font-extrabold">{stg.reward.toLocaleString()}원</p>
                            </div>
                          </div>

                          <div className="flex flex-wrap items-center justify-between gap-2.5 pt-2 border-t border-neutral-900">
                            {canEnter ? (
                              <div className="text-xs">
                                <span className="text-zinc-500">참전 무기: </span>
                                <span className={`font-bold ${getSwordLevelColor(bestUsableSword.level)}`}>+{bestUsableSword.level} {bestUsableSword.name}</span>
                                <span className="mx-1.5 text-zinc-600">|</span>
                                <span className="text-emerald-400 font-bold">승리 확률: {(winChance * 100).toFixed(0)}%</span>
                              </div>
                            ) : (
                              <p className="text-[11px] text-rose-500 italic">⚠️ 진입 규격 미달 또는 무기 부족 (+${stg.minLevel}강 이상 소요)</p>
                            )}

                            <div className="flex items-center gap-2">
                              {/* Automatic Combat Button */}
                              {isAutoCombat && autoCombatStageNum === stg.index ? (
                                <button
                                  onClick={() => {
                                    setIsAutoCombat(false);
                                    addLog(`[자동 전투] 🛑 유저가 자동 전투를 중단했습니다.`);
                                  }}
                                  className="py-1.5 px-3 rounded-lg font-black text-xs bg-amber-500 text-neutral-950 hover:bg-amber-400 animate-pulse active:scale-95 transition"
                                >
                                  🤖 자동전투 중단
                                </button>
                              ) : (
                                <button
                                  onClick={() => {
                                    if (!canEnter) return;
                                    setAutoCombatStageNum(stg.index);
                                    setIsAutoCombat(true);
                                    addLog(`[자동 전투] 🤖 Stage ${stg.index} (${stg.name}) 자동 전투를 활성화하여 연속 전투를 개시합니다!`);
                                    handleCombat(stg.index);
                                  }}
                                  disabled={isForging || !canEnter || isConsecutive}
                                  className={`py-1.5 px-3 rounded-lg font-black text-xs transition active:scale-95 ${
                                    isForging || !canEnter || isConsecutive
                                      ? 'bg-neutral-800/50 text-neutral-600 cursor-not-allowed'
                                      : 'bg-neutral-800 text-amber-400 border border-amber-500/20 hover:bg-neutral-700 hover:text-amber-300'
                                  }`}
                                >
                                  🤖 자동 전투
                                </button>
                              )}

                              <button
                                onClick={() => handleCombat(stg.index)}
                                disabled={isForging || isCombating || !canEnter}
                                className={`py-1.5 px-4 rounded-lg font-black text-xs transition relative active:scale-95 ${
                                  isForging || isCombating || !canEnter
                                    ? 'bg-neutral-800 text-neutral-500 cursor-not-allowed'
                                    : 'bg-gradient-to-r from-red-600 to-rose-500 text-white shadow-lg shadow-red-950/20 hover:from-red-500 hover:to-rose-400'
                                }`}
                              >
                                {isCombating && state.currentMap === stg.name ? '전사 전투중...' : '전투하기 (출격)'}
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Tab 4: Statistics */}
              {activeTab === 'stats' && (
                <div className="space-y-4">
                  <div className="bg-neutral-950 p-4 border border-neutral-800 rounded-xl space-y-2.5 text-xs font-mono">
                    <p className="text-amber-500 font-bold mb-2 text-sm">📈 이지모드 마하 강화 스탯</p>
                    <div className="flex justify-between border-b border-neutral-900 pb-1.5">
                      <span className="text-neutral-400">누적 시도 횟수:</span>
                      <span className="text-white font-bold">{state.statistics.totalAttempts}회</span>
                    </div>
                    <div className="flex justify-between border-b border-neutral-900 pb-1.5">
                      <span className="text-neutral-400">대성공 횟수:</span>
                      <span className="text-green-400 font-bold">{state.statistics.totalSuccesses}회</span>
                    </div>
                    <div className="flex justify-between border-b border-neutral-900 pb-1.5">
                      <span className="text-neutral-400">누적 낙방(실패) 횟수:</span>
                      <span className="text-yellow-500 font-bold">{state.statistics.totalFails}회</span>
                    </div>
                    <div className="flex justify-between border-b border-neutral-900 pb-1.5">
                      <span className="text-neutral-400">소중한 검 파괴 횟수:</span>
                      <span className="text-red-500 font-bold">{state.statistics.totalDestructions}회</span>
                    </div>
                    <div className="flex justify-between border-b border-neutral-900 pb-1.5">
                      <span className="text-neutral-400">누적 소비 대장비 자금:</span>
                      <span className="text-amber-400 font-bold">{state.statistics.totalMoneySpent.toLocaleString()}원</span>
                    </div>
                    <div className="flex justify-between pt-1">
                      <span className="text-neutral-400">역대 도달 최고 도수:</span>
                      <span className="text-cyan-400 font-black">+{state.statistics.maxLevelReached}강</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Right column (Classic terminal screen & Command box) */}
        <div className="lg:col-span-5 flex flex-col gap-6">
          
          {/* Output Format Fixed Card Box */}
          <div className="bg-neutral-950 border-2 border-neutral-800 rounded-2xl flex flex-col overflow-hidden shadow-2xl relative">
            <div className="bg-neutral-900/80 border-b border-neutral-850 px-4 py-3 flex items-center justify-between">
              <span className="text-xs font-mono text-zinc-400 font-bold flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse inline-block" />
                SYSTEM LIVE CONSOLE (FIXED FORMAT)
              </span>
              <span className="text-[10px] font-mono select-none px-2 py-0.5 bg-neutral-800 rounded text-neutral-400">
                UTF-8 ASCII
              </span>
            </div>

            {/* Readonly ASCII View representing EXACT required format! */}
            <div className="p-4 bg-black font-mono text-xs text-neutral-200 select-all whitespace-pre leading-relaxed border-b border-neutral-900 overflow-x-auto min-h-[175px]">
              {getRequiredAsciiUI()}
            </div>

            {/* Live Chat Log Feed (Forge History) */}
            <div className="flex-1 bg-black p-4 font-mono text-xs text-zinc-400 overflow-y-auto max-h-[310px] min-h-[220px] scrollbar-thin scrollbar-thumb-neutral-800 flex flex-col space-y-1.5">
              <p className="text-neutral-500 border-b border-neutral-900 pb-1 mb-2">📜 실시간 연성 대지 로그</p>
              {state.history.map((h, i) => (
                <div key={i} className="text-neutral-300 leading-normal flex gap-1 items-start">
                  <ChevronRight className="w-3.5 h-3.5 text-amber-500/80 shrink-0 mt-0.5" />
                  <span className="break-all">{h}</span>
                </div>
              ))}
              <div ref={consoleEndRef} />
            </div>

            {/* Chat / Command Interactive Box */}
            <form onSubmit={handleConsoleSubmit} className="bg-neutral-900/70 border-t border-neutral-850 p-2.5 flex items-center gap-2">
              <span className="text-amber-500 text-sm font-bold font-mono pl-1.5 select-none">&gt;</span>
              <input 
                type="text" 
                value={consoleInput}
                onChange={(e) => setConsoleInput(e.target.value)}
                placeholder="명령어를 입력하세요... (예: 강화, 판매, 상점, 조합소)" 
                className="flex-1 bg-transparent border-0 ring-0 focus:ring-0 focus:border-0 outline-none font-mono text-sm text-white placeholder-neutral-500"
              />
              <button 
                type="submit"
                className="bg-neutral-800 hover:bg-neutral-700 hover:text-white text-neutral-300 border border-neutral-700/60 px-3.5 py-1.5 rounded-lg text-xs font-black transition"
              >
                전송
              </button>
            </form>
          </div>

          {/* Quick Shortcuts helpful tips */}
          <div className="bg-neutral-900/50 border border-neutral-800 rounded-xl p-4 text-xs text-neutral-400 space-y-1.5">
            <p className="text-neutral-300 font-bold flex items-center gap-1.5">
              <Compass className="w-4 h-4 text-amber-500" />
              대장장이 속결 가이드 지침
            </p>
            <p className="leading-relaxed">
              ⌨️ <span className="font-bold text-neutral-300">Space 키</span>로 마우스 없이 빠르게 연속 강화가 가능하며, 바닥에 잡템이 떨어지면 <span className="font-bold text-neutral-300">F 또는 G 키</span>로 즉시 주울 수 있습니다. 상단 <span className="font-bold text-amber-300">[파일 다운로드 / 백업]</span> 버튼으로 전체 소스코드(ZIP)와 세이브 파일을 저장할 수 있습니다.
            </p>
          </div>

        </div>
      </main>

      {/* File & Code Export Modal */}
      <FileModal
        isOpen={showFileModal}
        onClose={() => setShowFileModal(false)}
        gameState={state}
        warpTickets={warpTickets}
        onRestoreState={handleRestoreState}
        addLog={addLog}
      />
    </div>
  );
}
