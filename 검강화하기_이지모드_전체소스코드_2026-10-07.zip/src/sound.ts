class SoundManager {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;

  private init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public toggleMute() {
    this.isMuted = !this.isMuted;
    return this.isMuted;
  }

  public getMuteState() {
    return this.isMuted;
  }

  private playTone(freq: number, type: OscillatorType, duration: number, gainStart: number, delay = 0) {
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime + delay);

    gainNode.gain.setValueAtTime(gainStart, this.ctx.currentTime + delay);
    gainNode.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + delay + duration);

    osc.connect(gainNode);
    gainNode.connect(this.ctx.destination);

    osc.start(this.ctx.currentTime + delay);
    osc.stop(this.ctx.currentTime + delay + duration);
  }

  public playForge() {
    // 금속 때리는 소리: 아주 높은 고주파 오실레이터 합성과 메탈 성분 노이즈 느낌
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    // 1번음: 쨍한 쇠소리 (고음 사인-삼각파)
    this.playTone(1200, 'triangle', 0.15, 0.4);
    this.playTone(2400, 'sine', 0.08, 0.2);
    // 2번음: 무거운 대장간 둔탁음 (저음)
    this.playTone(180, 'sawtooth', 0.25, 0.3);
  }

  public playSuccess() {
    // 성공 시 상승 하모니
    const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
    notes.forEach((freq, index) => {
      this.playTone(freq, 'sine', 0.25, 0.2, index * 0.08);
    });
  }

  public playFail() {
    // 파괴 안 되고 단지 실패만 했을 때 (방지권 소모 시 또는 안전구간 실패)
    const notes = [392.00, 349.23, 311.13]; // G4, F4, D#4
    notes.forEach((freq, index) => {
      this.playTone(freq, 'sawtooth', 0.3, 0.15, index * 0.1);
    });
  }

  public playDestruct() {
    // 콰과광... 파쉬익... 소멸 소리
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    // 1단계: 강하게 파괴적인 충격음
    this.playTone(90, 'sawtooth', 0.5, 0.5);
    this.playTone(150, 'sawtooth', 0.3, 0.4);

    // 2단계: 스릴러식 디센딩 글라이드 노이즈 느낌
    const duration = 0.6;
    const osc = this.ctx.createOscillator();
    const gainNode = this.ctx.createGain();
    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(400, this.ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(40, this.ctx.currentTime + duration);

    gainNode.gain.setValueAtTime(0.3, this.ctx.currentTime);
    gainNode.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration);

    osc.connect(gainNode);
    gainNode.connect(this.ctx.destination);
    osc.start();
    osc.stop(this.ctx.currentTime + duration);
  }

  public playSell() {
    // 동전 쏟아지는 찬짝짝 소리
    const coins = [987.77, 1318.51, 1567.98, 1975.53];
    coins.forEach((freq, index) => {
      this.playTone(freq, 'sine', 0.15, 0.15, index * 0.05);
      this.playTone(freq * 1.5, 'triangle', 0.1, 0.1, index * 0.05 + 0.02);
    });
  }

  public playBuy() {
    // 상점 상호작용 짤그랑
    this.playTone(1046.50, 'sine', 0.1, 0.2);
    this.playTone(1567.98, 'sine', 0.15, 0.15, 0.05);
  }

  public playPickup() {
    // 아이템 주울 때 뿅!
    this.playTone(880, 'sine', 0.12, 0.2);
    this.playTone(1320, 'sine', 0.15, 0.15, 0.04);
  }

  public playCheer() {
    // 최종 클리어 소리! 기쁨의 대향연
    if (this.isMuted) return;
    this.init();
    if (!this.ctx) return;

    const chords = [261.63, 329.63, 392.00, 523.25, 659.25, 783.99, 1046.50];
    chords.forEach((freq, i) => {
      this.playTone(freq, 'sine', 1.5, 0.1, i * 0.04);
      this.playTone(freq * 1.2, 'triangle', 1.2, 0.08, i * 0.04 + 0.1);
    });
  }
}

export const sound = new SoundManager();
