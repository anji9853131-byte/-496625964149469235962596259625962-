export interface SwordInfo {
  level: number;
  name: string;
  cost: number;
  probability: number; // 0.0 ~ 1.0
  sellPrice: number; // -1 means cannot sell
  protectNeed: number; // 0 or higher
  dropItem?: JunkType;
  material?: {
    type: 'weapon' | 'junk';
    key: string;
    count: number;
  };
  isStorageRequired?: boolean;
  isHardMode?: boolean; // Protect cards disabled automatically
}

export type JunkType =
  | 'ironPiece' // 국적불분명 철조각
  | 'tauBone' // 타우의 뼈 부스러기
  | 'fluorescence' // 빛 바랜 형광물질
  | 'swissIron' // 스위스산 철조각
  | 'fieryHandle' // 불꽃마검 손잡이
  | 'evilSoul' // 사악한 영혼
  | 'axePowder' // 도끼 가루
  | 'invisibleMaterial'; // 투명 물질

export interface JSTState {
  ironPiece: number;
  tauBone: number;
  fluorescence: number;
  swissIron: number;
  fieryHandle: number;
  evilSoul: number;
  axePowder: number;
  invisibleMaterial: number;
}

export interface GameState {
  difficulty: 'EASY';
  money: number;
  currentSwordLevel: number;
  protectCards: number;
  storage: {
    wangpu: number; // 왕푸야샤
    tempest: number; // 템페스트 골드
    sharp: number; // 샤프 워커
  };
  junks: JSTState;
  droppedJunk: {
    type: JunkType;
    count: number;
  } | null;
  tempStorage: Array<{
    level: number;
    name: string;
  }>;
  currentMap: string;
  protectCardEnabled: boolean;
  history: string[]; // 게임 로그
  statistics: {
    totalAttempts: number;
    totalSuccesses: number;
    totalFails: number;
    totalDestructions: number;
    totalMoneySpent: number;
    maxLevelReached: number;
  };
}

export const JUNK_NAMES: Record<JunkType, string> = {
  ironPiece: '차가운 심해의 철광 석판',
  tauBone: '고대 파괴수 바소렉의 상아 뼈 화석',
  fluorescence: '성령의 푸른빛 에테르 성수',
  swissIron: '은빛 용황 가리온의 비늘 파편',
  fieryHandle: '지옥불 불태우는 불안정한 손잡이',
  evilSoul: '망각의 나락에서 울부짖는 원혼',
  axePowder: '차원을 참수하는 무한 마력 가루',
  invisibleMaterial: '시공간 왜곡의 보이드 암흑 물질',
};

export const SWORDS_DB: Record<number, SwordInfo> = {
  0: {
    level: 0,
    name: '녹슬고 이 빠진 무딘 단검',
    cost: 300,
    probability: 1.0,
    sellPrice: -1,
    protectNeed: 0,
  },
  1: {
    level: 1,
    name: '초보 모험가의 강철 칼날',
    cost: 300,
    probability: 1.0,
    sellPrice: 150,
    protectNeed: 0,
  },
  2: {
    level: 2,
    name: '은빛 달빛을 서약한 수호도',
    cost: 500,
    probability: 1.0,
    sellPrice: 400,
    protectNeed: 0,
  },
  3: {
    level: 3,
    name: '북해 무법자의 영광 바이킹 소드',
    cost: 500,
    probability: 0.95,
    sellPrice: 600,
    protectNeed: 0,
  },
  4: {
    level: 4,
    name: '피어오르는 홍련검 브렌트',
    cost: 1000,
    probability: 0.95,
    sellPrice: 800,
    protectNeed: 0,
  },
  5: {
    level: 5,
    name: '빙결 칼바람의 극광 윈터가르드',
    cost: 1500,
    probability: 0.90,
    sellPrice: 1600,
    protectNeed: 0,
  },
  6: {
    level: 6,
    name: '대지를 분쇄하는 사형 참수검',
    cost: 2000,
    probability: 0.90,
    sellPrice: 3500,
    protectNeed: 1,
    dropItem: 'ironPiece',
  },
  7: {
    level: 7,
    name: '천상의 빛의 심판자 에스텔라',
    cost: 2000,
    probability: 0.90,
    sellPrice: 6100,
    protectNeed: 1,
    dropItem: 'ironPiece',
  },
  8: {
    level: 8,
    name: '비전 마나 소용돌이 아케인 세이버',
    cost: 3000,
    probability: 0.85,
    sellPrice: 10000,
    protectNeed: 1,
    dropItem: 'ironPiece',
  },
  9: {
    level: 9,
    name: '대야수 미노타우로스의 끓는 격노검',
    cost: 5000,
    probability: 0.80,
    sellPrice: 20000,
    protectNeed: 1,
    dropItem: 'tauBone',
  },
  10: {
    level: 10,
    name: '오라 플레어 에메랄드 크러셔',
    cost: 10900,
    probability: 0.80,
    sellPrice: 35100,
    protectNeed: 1,
    dropItem: 'fluorescence',
  },
  11: {
    level: 11,
    name: '선혈을 머금은 원령의 자비',
    cost: 20000,
    probability: 0.75,
    sellPrice: 160000,
    protectNeed: 1,
    dropItem: 'swissIron',
  },
  12: {
    level: 12,
    name: '멸망의 작열하는 쌍검 카타스트로프',
    cost: 35000,
    probability: 0.70,
    sellPrice: 350000,
    protectNeed: 1,
    dropItem: 'swissIron',
  },
  13: {
    level: 13,
    name: '연옥의 맹화 헬하임 소울 이터',
    cost: 55000,
    probability: 0.70,
    sellPrice: 1000000,
    protectNeed: 2,
    dropItem: 'fieryHandle',
  },
  14: {
    level: 14,
    name: '성배수 성문 너머의 아포피스 시미터',
    cost: 100000,
    probability: 0.65,
    sellPrice: 3000000,
    protectNeed: 3,
    dropItem: 'evilSoul',
  },
  15: {
    level: 15,
    name: '종말의 데몬 헤일 배틀 엑스',
    cost: 180000,
    probability: 0.60,
    sellPrice: 7500000,
    protectNeed: 4,
    dropItem: 'axePowder',
  },
  16: {
    level: 16,
    name: '무형의 차원 붕괴 보이드 팬텀',
    cost: 300000,
    probability: 0.60,
    sellPrice: 14200000,
    protectNeed: 7,
    dropItem: 'invisibleMaterial',
  },
  17: {
    level: 17,
    name: '황금룡 바실리우스의 광휘 성소검',
    cost: 300000,
    probability: 0.55,
    sellPrice: 20000000,
    protectNeed: 9,
  },
  18: {
    level: 18,
    name: '은하수가 수놓인 영겁의 스카이 글로우',
    cost: 500000,
    probability: 0.50,
    sellPrice: 30000000,
    protectNeed: 10,
  },
  19: {
    level: 19,
    name: '전뇌 카두케우스',
    cost: 800000,
    probability: 0.50,
    sellPrice: 47500000,
    protectNeed: 12,
    isStorageRequired: true,
  },
  20: {
    level: 20,
    name: '무지개빛 환영을 흩뿌리는 신수검',
    cost: 1500000,
    probability: 0.45,
    sellPrice: 68300000,
    protectNeed: 15,
  },
  21: {
    level: 21,
    name: '템페스트 가브리엘',
    cost: 0,
    probability: 0.40,
    sellPrice: 101000000,
    protectNeed: 17,
    isStorageRequired: true,
    material: {
      type: 'weapon',
      key: 'wangpu',
      count: 1,
    },
  },
  22: {
    level: 22,
    name: '광속의 크로노스',
    cost: 0,
    probability: 0.40,
    sellPrice: 160000000,
    protectNeed: 20,
    isStorageRequired: true,
    material: {
      type: 'weapon',
      key: 'tempest',
      count: 2,
    },
  },
  23: {
    level: 23,
    name: '광대의 저주받은 더블 사념 피에로',
    cost: 0,
    probability: 0.40,
    sellPrice: 230000000,
    protectNeed: 22,
    material: {
      type: 'junk',
      key: 'evilSoul',
      count: 8,
    },
  },
  24: {
    level: 24,
    name: '용들의 눈물을 벤 드래곤 슬레이어',
    cost: 0,
    probability: 0.40,
    sellPrice: 300000000,
    protectNeed: 23,
    material: {
      type: 'weapon',
      key: 'sharp',
      count: 1,
    },
  },
  25: {
    level: 25,
    name: '심안으로 베는 지극히 평범한 목검',
    cost: 0,
    probability: 0.35,
    sellPrice: 400000000,
    protectNeed: 23,
    material: {
      type: 'junk',
      key: 'axePowder',
      count: 15,
    },
  },
  26: {
    level: 26,
    name: '석화 마안 고르곤의 심령 사도검',
    cost: 5000000,
    probability: 0.50,
    sellPrice: 1800000000,
    protectNeed: 0,
    isHardMode: true,
  },
  27: {
    level: 27,
    name: '초월적 별무리 오딧세이 코스모스',
    cost: 0,
    probability: 0.40,
    sellPrice: 2500000000,
    protectNeed: 0,
    isHardMode: true,
    material: {
      type: 'junk',
      key: 'invisibleMaterial',
      count: 2,
    },
  },
  28: {
    level: 28,
    name: '패러독스 모자이크 오버로드',
    cost: 0,
    probability: 0.15,
    sellPrice: -1,
    protectNeed: 0,
    isHardMode: true,
  },
  29: {
    level: 29,
    name: '영겁의 아포칼립스',
    cost: 0,
    probability: 0,
    sellPrice: -1,
    protectNeed: 0,
  },
};
