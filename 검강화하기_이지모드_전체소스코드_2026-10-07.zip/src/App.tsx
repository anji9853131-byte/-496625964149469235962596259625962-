/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import ForgeGame from './components/ForgeGame';

export default function App() {
  return (
    <ForgeGame />
  );
}

