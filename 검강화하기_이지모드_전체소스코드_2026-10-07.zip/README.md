# 검 강화하기 (이지 모드) - 풀 소스코드

고전 명작 플래시 게임 '검 강화하기' 이지 모드 웹 시뮬레이터입니다.
웹 오디오 기반 레트로 사운드, 다양한 무기/던전/창고/조합 시스템이 탑재되어 있습니다.

---

## 🛠️ PC 로컬 실행 방법 (빠른 시작)

### 1. 사전 준비
- **Node.js (v18 이상 권장)**: [https://nodejs.org](https://nodejs.org) 에서 설치

### 2. 의존성 패키지 설치
압축을 푼 폴더에서 터미널(또는 CMD/PowerShell)을 열고 아래 명령어를 입력합니다:
```bash
npm install
```

### 3. 개발 서버 실행 (게임 시작)
```bash
npm run dev
```
터미널에 안내되는 로컬 주소(기본: `http://localhost:3000` 또는 `http://localhost:5173`)를 크롬이나 엣지 등 브라우저로 열면 즉시 플레이할 수 있습니다.

### 4. 배포용 정적 빌드
```bash
npm run build
```
빌드 완료 후 `dist` 폴더에 생성되는 HTML/JS/CSS 파일을 무료 호스팅(Vercel, Netlify, GitHub Pages 등)에 바로 배포할 수도 있습니다.
